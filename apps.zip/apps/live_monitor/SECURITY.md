# Bezpieczeństwo prototypu

Ta aplikacja powstała jako demonstrator badawczy. Nie należy przechowywać w niej
rzeczywistych danych medycznych ani używać jej do podejmowania decyzji klinicznych.

Przed wdrożeniem należałoby co najmniej:

- zastąpić logowanie oparte na polu `password` usługą Firebase Authentication;
- usunąć możliwość odczytu haseł i zastosować reguły Firestore z kontrolą ról;
- ograniczyć dostęp pacjenta do jego własnych dokumentów;
- wdrożyć zgodę użytkownika, retencję danych, szyfrowanie i rejestr operacji;
- przeprowadzić analizę ryzyka, testy bezpieczeństwa i ocenę wymagań prawnych;
- zwalidować algorytm na niezależnej aparaturze referencyjnej i większej grupie.

Nie publikuj plików `google-services.json`, kluczy podpisu, haseł ani wartości
używanych w `--dart-define`.
