import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_application_1/main.dart';

void main() {
  testWidgets('login screen starts', (tester) async {
    await tester.pumpWidget(const NoseApp());

    expect(find.text('NOSE'), findsOneWidget);
    expect(find.text('Prototyp monitorowania oddechu'), findsOneWidget);
    expect(find.text('ZALOGUJ SIĘ'), findsOneWidget);
  });
}
