import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

// FIREBASE IMPORTS
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

const String serviceUuid =
    '4fafc201-1fb5-459e-8fcc-c5c9c331914b'; // Ujednolicone UUID z pasów
const String characteristicUuid = 'beb5483e-36e1-4688-b7f5-ea07361b26a8';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalSessionStore.initialize();
  runApp(const NoseApp());
  unawaited(FirebaseBootstrap.initialize());
}

class FirebaseBootstrap {
  static final ValueNotifier<bool> availability = ValueNotifier(false);
  static Future<bool>? _initialization;

  static Future<bool> initialize() {
    return _initialization ??= _initializeOnce();
  }

  static Future<bool> _initializeOnce() async {
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      }
      availability.value = true;
      return true;
    } catch (error) {
      debugPrint('Firebase niedostępny: $error');
      availability.value = false;
      _initialization = null;
      return false;
    }
  }
}

// ==========================================
// TYPY URZĄDZEŃ
// ==========================================
enum DeviceType { mask, tensometricBelt, barometricBelt }

String getDeviceDisplayName(DeviceType type) {
  switch (type) {
    case DeviceType.mask:
      return 'Urządzenie z czujnikami temperatury';
    case DeviceType.tensometricBelt:
      return 'Pas tensometryczny';
    case DeviceType.barometricBelt:
      return 'Pas barometryczny';
  }
}

// ==========================================
// MODELE DANYCH Z FIREBASE
// ==========================================

class ApneaEvent {
  final DateTime startTime;
  final int durationSeconds;
  ApneaEvent({required this.startTime, required this.durationSeconds});

  Map<String, dynamic> toMap() => {
    'startTime': startTime.toIso8601String(),
    'durationSeconds': durationSeconds,
  };
  static ApneaEvent fromMap(Map<String, dynamic> map) => ApneaEvent(
    startTime: DateTime.parse(map['startTime']),
    durationSeconds: map['durationSeconds'],
  );
}

class SessionDataPoint {
  final DateTime time;
  final double mouthTemp;
  final double noseTemp;

  SessionDataPoint({
    required this.time,
    required this.mouthTemp,
    required this.noseTemp,
  });
  Map<String, dynamic> toMap() => {
    't': time.toIso8601String(),
    'm': double.parse(mouthTemp.toStringAsFixed(2)),
    'n': double.parse(noseTemp.toStringAsFixed(2)),
  };
  static SessionDataPoint fromMap(Map<String, dynamic> map) => SessionDataPoint(
    time: DateTime.parse(map['t']),
    mouthTemp: map['m'].toDouble(),
    noseTemp: map['n'].toDouble(),
  );
}

class SessionRecord {
  final String? id;
  final DateTime startTime;
  final DateTime endTime;
  final double avgRr;
  final bool apneaMonitored;
  final List<ApneaEvent> apneaEvents;
  final double mouthPercentage;
  final double nosePercentage;
  final List<SessionDataPoint> waveform;
  final String deviceType; // Dodano typ urządzenia

  SessionRecord({
    this.id,
    required this.startTime,
    required this.endTime,
    required this.avgRr,
    required this.apneaMonitored,
    required this.apneaEvents,
    required this.mouthPercentage,
    required this.nosePercentage,
    required this.waveform,
    this.deviceType = 'mask',
  });

  Duration get duration => endTime.difference(startTime);

  double get apneaEventsPerHour {
    final hours = duration.inSeconds / 3600.0;
    if (hours <= 0) return 0.0;
    return apneaEvents.length / hours;
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      // avgBpm pozostaje wyłącznie kluczem zgodności ze starszymi zapisami.
      'avgBpm': avgRr,
      'avgRr': avgRr,
      'apneaMonitored': apneaMonitored,
      'mouthPercentage': mouthPercentage,
      'nosePercentage': nosePercentage,
      'apneaEvents': apneaEvents.map((e) => e.toMap()).toList(),
      'waveform': waveform.map((w) => w.toMap()).toList(),
      'deviceType': deviceType,
    };
  }

  static SessionRecord fromMap(String docId, Map<String, dynamic> map) {
    final apneaMaps = (map['apneaEvents'] as List?) ?? const [];
    final waveformMaps = (map['waveform'] as List?) ?? const [];
    return SessionRecord(
      id: docId.isNotEmpty ? docId : map['id']?.toString(),
      startTime: DateTime.parse(map['startTime']),
      endTime: DateTime.parse(map['endTime']),
      avgRr: ((map['avgRr'] ?? map['avgBpm'] ?? 0) as num).toDouble(),
      apneaMonitored: map['apneaMonitored'] as bool? ?? false,
      mouthPercentage: (map['mouthPercentage'] as num? ?? 0).toDouble(),
      nosePercentage: (map['nosePercentage'] as num? ?? 0).toDouble(),
      apneaEvents: apneaMaps
          .map((e) => ApneaEvent.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
      waveform: waveformMaps
          .map(
            (w) =>
                SessionDataPoint.fromMap(Map<String, dynamic>.from(w as Map)),
          )
          .toList(),
      deviceType: map['deviceType']?.toString() ?? DeviceType.mask.toString(),
    );
  }

  SessionRecord copyWithId(String newId) => SessionRecord(
    id: newId,
    startTime: startTime,
    endTime: endTime,
    avgRr: avgRr,
    apneaMonitored: apneaMonitored,
    apneaEvents: apneaEvents,
    mouthPercentage: mouthPercentage,
    nosePercentage: nosePercentage,
    waveform: waveform,
    deviceType: deviceType,
  );
}

class LocalSessionStore {
  static final ValueNotifier<List<SessionRecord>> records =
      ValueNotifier<List<SessionRecord>>(<SessionRecord>[]);
  static File? _file;

  static Future<void> initialize() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      _file = File(
        '${directory.path}${Platform.pathSeparator}nose_sessions.json',
      );
      if (!await _file!.exists()) return;
      final decoded = jsonDecode(await _file!.readAsString());
      if (decoded is! List) return;
      final loaded =
          decoded
              .whereType<Map>()
              .map(
                (item) =>
                    SessionRecord.fromMap('', Map<String, dynamic>.from(item)),
              )
              .toList()
            ..sort((a, b) => b.startTime.compareTo(a.startTime));
      records.value = loaded;
    } catch (error) {
      debugPrint('Nie udało się odczytać lokalnej historii: $error');
    }
  }

  static Future<SessionRecord> save(SessionRecord record) async {
    final stored = record.id == null
        ? record.copyWithId('local_${record.startTime.microsecondsSinceEpoch}')
        : record;
    final updated = <SessionRecord>[
      stored,
      ...records.value.where((item) => item.id != stored.id),
    ]..sort((a, b) => b.startTime.compareTo(a.startTime));
    records.value = updated;
    await _persist();
    return stored;
  }

  static Future<void> delete(String id) async {
    records.value = records.value.where((item) => item.id != id).toList();
    await _persist();
  }

  static Future<void> _persist() async {
    final file = _file;
    if (file == null) return;
    try {
      final temporary = File('${file.path}.tmp');
      await temporary.writeAsString(
        jsonEncode(records.value.map((record) => record.toMap()).toList()),
        flush: true,
      );
      if (await file.exists()) await file.delete();
      await temporary.rename(file.path);
    } catch (error) {
      debugPrint('Nie udało się zapisać lokalnej historii: $error');
    }
  }
}

class PatientProfile {
  final String id;
  final String login;
  final String password;
  final String fullName;
  final double weight;
  final double height;
  final String medicalHistory;

  PatientProfile({
    required this.id,
    required this.login,
    required this.password,
    required this.fullName,
    required this.weight,
    required this.height,
    required this.medicalHistory,
  });

  factory PatientProfile.offline() => PatientProfile(
    id: 'offline',
    login: '',
    password: '',
    fullName: 'Tryb lokalny',
    weight: 0,
    height: 0,
    medicalHistory: '',
  );

  static PatientProfile fromMap(String docId, Map<String, dynamic> map) {
    return PatientProfile(
      id: docId,
      login: map['login'] ?? '',
      password: map['password'] ?? '',
      fullName: map['fullName'] ?? '',
      weight: (map['weight'] ?? 0).toDouble(),
      height: (map['height'] ?? 0).toDouble(),
      medicalHistory: map['medicalHistory'] ?? '',
    );
  }
}

// ==========================================
// MODELE SYGNAŁOWE BLE
// ==========================================

enum AppSection { dashboard, apnea, history, charts, rawData }

enum BreathState { inhale, exhale }

enum BreathingRoute { mouth, nose }

enum RrWindowMode { tenSeconds, twentySeconds }

enum AnalyzerKind { temperature, belt }

extension RrWindowModeLabel on RrWindowMode {
  int get seconds {
    switch (this) {
      case RrWindowMode.tenSeconds:
        return 10;
      case RrWindowMode.twentySeconds:
        return 20;
    }
  }

  String get label => '$seconds s';
}

class SensorSample {
  final double t0, h0, t1, h1, t2, h2, tAmb, hAmb;
  const SensorSample({
    required this.t0,
    required this.h0,
    required this.t1,
    required this.h1,
    required this.t2,
    required this.h2,
    required this.tAmb,
    required this.hAmb,
  });

  double get tempMouth => t0 - tAmb;
  double get humMouth => h0 - hAmb;
  double get tempRight => t1 - tAmb;
  double get humRight => h1 - hAmb;
  double get tempLeft => t2 - tAmb;
  double get humLeft => h2 - hAmb;
  double get tempNose => (tempRight + tempLeft) / 2.0;

  static SensorSample? fromCsv(String text) {
    final parts = text.trim().split(',');
    if (parts.length != 8) return null;
    try {
      return SensorSample(
        t0: double.parse(parts[0]),
        h0: double.parse(parts[1]),
        t1: double.parse(parts[2]),
        h1: double.parse(parts[3]),
        t2: double.parse(parts[4]),
        h2: double.parse(parts[5]),
        tAmb: double.parse(parts[6]),
        hAmb: double.parse(parts[7]),
      );
    } catch (_) {
      return null;
    }
  }
}

class StateSegment {
  double startX;
  double endX;
  final BreathState state;
  StateSegment({required this.startX, required this.endX, required this.state});
}

class TimedValue {
  final double timeSeconds;
  final double value;
  const TimedValue(this.timeSeconds, this.value);
}

class TimedRouteVote {
  final DateTime time;
  final BreathingRoute route;
  const TimedRouteVote(this.time, this.route);
}

// ==========================================
// PRZETWARZANIE SYGNAŁÓW (Maska + Pasy)
// ==========================================

class ChannelAnalyzer {
  static const int maxPoints = 260;
  static const double chartWindowSeconds = 20.0;
  static const int smoothWindow = 5;
  static const int slopeWindow = 8;
  static const int rrHistorySeconds = 120;
  static const double emaAlpha = 0.15;
  static const double maximumAnalysisWindowSeconds = 20.0;

  final AnalyzerKind kind;
  double slopeDeadband = 0.015;
  double noiseThreshold;
  double simpleSensitivity;

  final Queue<TimedValue> _rawValues = ListQueue();
  final Queue<TimedValue> _filteredHistory = ListQueue();
  final Queue<TimedValue> _phaseMeans = ListQueue();
  final Queue<DateTime> _inhaleTimestamps = ListQueue();
  final Queue<DateTime> _transitionTimestamps = ListQueue();

  final List<FlSpot> spots = [];
  final List<FlSpot> rawSpots = [];
  final List<FlSpot> humiditySpots = [];
  final List<StateSegment> segments = [];

  BreathState currentState = BreathState.exhale;
  int recentTransitions = 0;
  double currentTemp = 0.0;
  double currentHum = 0.0;
  double currentRawTemp = 0.0;
  double currentSlope = 0.0;
  double phaseThreshold = 0.0;
  double filteredValue = 0.0;

  ChannelAnalyzer.temperature()
    : kind = AnalyzerKind.temperature,
      noiseThreshold = 0.2,
      simpleSensitivity = 0.015;

  ChannelAnalyzer.belt({this.simpleSensitivity = 0.05})
    : kind = AnalyzerKind.belt,
      noiseThreshold = 0.0;

  String get filterName => 'Detrend liniowy + EMA (α=0,15)';
  String get estimatorName => kind == AnalyzerKind.belt
      ? 'Detekcja lokalnych maksimów'
      : 'Metoda nachylenia sygnału';
  String get phaseMethodName => 'SMA (5) + regresja liniowa (8 próbek)';
  DateTime? get lastBreathTime =>
      _inhaleTimestamps.isNotEmpty ? _inhaleTimestamps.last : null;
  int get rawSampleCount => _rawValues.length;

  void processTemperature(
    double timeSeconds,
    DateTime receivedAt,
    double tempValue,
    double humValue,
    double rawTemp, {
    int analysisWindowSeconds = 10,
  }) {
    if (!tempValue.isFinite) return;
    currentTemp = tempValue;
    currentHum = humValue;
    currentRawTemp = rawTemp;
    _appendRaw(timeSeconds, tempValue);

    final prepared = _preparedSeries(analysisWindowSeconds.toDouble());
    if (prepared.isEmpty) return;
    filteredValue = prepared.last.value;
    _appendPlotPoint(spots, FlSpot(timeSeconds, filteredValue));
    _appendPlotPoint(rawSpots, FlSpot(timeSeconds, tempValue));
    if (humValue.isFinite) {
      _appendPlotPoint(humiditySpots, FlSpot(timeSeconds, humValue));
    }

    _filteredHistory.addLast(TimedValue(timeSeconds, filteredValue));
    _trimTimedQueue(
      _filteredHistory,
      timeSeconds,
      maximumAnalysisWindowSeconds,
    );
    final recentFiltered = _filteredHistory.toList();
    final smoothStart = math.max(0, recentFiltered.length - smoothWindow);
    final smoothValues = recentFiltered.sublist(smoothStart);
    final phaseMean =
        smoothValues.fold<double>(0, (total, item) => total + item.value) /
        smoothValues.length;
    _phaseMeans.addLast(TimedValue(timeSeconds, phaseMean));
    _trimTimedQueue(_phaseMeans, timeSeconds, maximumAnalysisWindowSeconds);

    currentSlope = _slopeOfLast(_phaseMeans.toList(), slopeWindow);
    var newState = currentState;
    if (currentSlope > slopeDeadband) {
      newState = BreathState.exhale;
    } else if (currentSlope < -slopeDeadband) {
      newState = BreathState.inhale;
    }

    if (currentState == BreathState.exhale && newState == BreathState.inhale) {
      if (recentAmplitude(15, nowSeconds: timeSeconds) >= noiseThreshold) {
        _recordBreath(receivedAt);
      }
    }
    _updateSegmentsAndState(timeSeconds, receivedAt, newState);
  }

  void processBelt(
    double timeSeconds,
    DateTime receivedAt,
    double rawValue, {
    int analysisWindowSeconds = 10,
  }) {
    if (!rawValue.isFinite) return;
    _appendRaw(timeSeconds, rawValue);
    final prepared = _preparedSeries(analysisWindowSeconds.toDouble());
    if (prepared.isEmpty) return;
    filteredValue = prepared.last.value;
    _appendPlotPoint(spots, FlSpot(timeSeconds, filteredValue));
    _appendPlotPoint(rawSpots, FlSpot(timeSeconds, rawValue));

    _filteredHistory.addLast(TimedValue(timeSeconds, filteredValue));
    _trimTimedQueue(
      _filteredHistory,
      timeSeconds,
      maximumAnalysisWindowSeconds,
    );

    final filtered = _filteredHistory.toList();
    final smoothStart = math.max(0, filtered.length - smoothWindow);
    final smoothValues = filtered.sublist(smoothStart);
    final phaseMean =
        smoothValues.fold<double>(0, (total, item) => total + item.value) /
        smoothValues.length;
    _phaseMeans.addLast(TimedValue(timeSeconds, phaseMean));
    _trimTimedQueue(_phaseMeans, timeSeconds, maximumAnalysisWindowSeconds);

    var newState = currentState;
    if (_phaseMeans.length >= slopeWindow) {
      final recent = _phaseMeans
          .where((item) => item.timeSeconds >= timeSeconds - 6)
          .toList();
      final values = recent.map((item) => item.value).toList();
      final amplitude = values.length < 2
          ? 0.0
          : values.reduce(math.max) - values.reduce(math.min);
      if (amplitude >= simpleSensitivity) {
        final minimum = values.reduce(math.min);
        final normalized = recent
            .map(
              (item) => TimedValue(
                item.timeSeconds,
                (item.value - minimum) / amplitude,
              ),
            )
            .toList();
        currentSlope = _slopeOfLast(normalized, slopeWindow);
        phaseThreshold = slopeDeadband;

        if (currentSlope > phaseThreshold) {
          newState = BreathState.inhale;
        } else if (currentSlope < -phaseThreshold) {
          newState = BreathState.exhale;
        }
        if (currentState == BreathState.inhale &&
            newState == BreathState.exhale) {
          _recordBreath(receivedAt);
        }
      }
    }
    _updateSegmentsAndState(timeSeconds, receivedAt, newState);
  }

  double respiratoryRateInWindow(int windowSeconds) {
    if (kind == AnalyzerKind.belt) {
      return _peakRateInWindow(windowSeconds.toDouble());
    }
    return _slopeCountRateInWindow(windowSeconds.toDouble());
  }

  int recentBreathCount(Duration window, {DateTime? now}) {
    final current = now ?? DateTime.now();
    _trimInhaleHistory(current);
    final start = current.subtract(window);
    return _inhaleTimestamps.where((item) => !item.isBefore(start)).length;
  }

  double recentAmplitude(double seconds, {double? nowSeconds}) {
    if (_rawValues.isEmpty) return 0;
    final end = nowSeconds ?? _rawValues.last.timeSeconds;
    final start = end - seconds;
    final values = _rawValues
        .where((item) => item.timeSeconds >= start)
        .map((item) => item.value)
        .toList();
    if (values.length < 2) return 0;
    return values.reduce(math.max) - values.reduce(math.min);
  }

  double signalQuality(double seconds, {double? nowSeconds}) {
    final amplitude = recentAmplitude(seconds, nowSeconds: nowSeconds);
    final reference = kind == AnalyzerKind.temperature
        ? noiseThreshold
        : math.max(simpleSensitivity * 4, 1e-9);
    return (amplitude / reference).clamp(0.0, 5.0).toDouble();
  }

  List<TimedValue> _preparedSeries(double windowSeconds) {
    if (_rawValues.length < 2) return const [];
    final end = _rawValues.last.timeSeconds;
    final start = end - windowSeconds;
    final samples = _rawValues
        .where((item) => item.timeSeconds >= start)
        .toList();
    if (samples.length < 2) return samples;

    final origin = samples.first.timeSeconds;
    final n = samples.length.toDouble();
    double sumX = 0;
    double sumY = 0;
    double sumXY = 0;
    double sumX2 = 0;
    for (final sample in samples) {
      final x = sample.timeSeconds - origin;
      sumX += x;
      sumY += sample.value;
      sumXY += x * sample.value;
      sumX2 += x * x;
    }
    final denominator = n * sumX2 - sumX * sumX;
    final slope = denominator.abs() < 1e-12
        ? 0.0
        : (n * sumXY - sumX * sumY) / denominator;
    final intercept = (sumY - slope * sumX) / n;

    final output = <TimedValue>[];
    double ema = samples.first.value - intercept;
    for (var index = 0; index < samples.length; index++) {
      final sample = samples[index];
      final x = sample.timeSeconds - origin;
      final detrended = sample.value - (slope * x + intercept);
      ema = index == 0
          ? detrended
          : emaAlpha * detrended + (1 - emaAlpha) * ema;
      output.add(TimedValue(sample.timeSeconds, ema));
    }
    return output;
  }

  double _peakRateInWindow(double windowSeconds) {
    final prepared = _preparedSeries(windowSeconds);
    if (prepared.length < 4) return 0;
    final values = prepared.map((item) => item.value).toList();
    final mean = values.reduce((a, b) => a + b) / values.length;
    final variance =
        values.fold<double>(
          0,
          (total, value) => total + math.pow(value - mean, 2),
        ) /
        values.length;
    final minimumProminence = math.max(math.sqrt(variance) * 0.25, 1e-9);
    const minimumInterval = 60.0 / 45.0;
    const maximumInterval = 60.0 / 5.0;
    final peaks = <int>[];

    for (var index = 1; index < values.length - 1; index++) {
      if (!(values[index] > values[index - 1] &&
          values[index] >= values[index + 1])) {
        continue;
      }
      var left = index - 1;
      while (left > 0 &&
          prepared[index].timeSeconds - prepared[left].timeSeconds <
              minimumInterval) {
        left--;
      }
      var right = index + 1;
      while (right < values.length - 1 &&
          prepared[right].timeSeconds - prepared[index].timeSeconds <
              minimumInterval) {
        right++;
      }
      final leftMinimum = values.sublist(left, index + 1).reduce(math.min);
      final rightMinimum = values.sublist(index, right + 1).reduce(math.min);
      final prominence = values[index] - math.max(leftMinimum, rightMinimum);
      if (prominence < minimumProminence) continue;

      if (peaks.isNotEmpty &&
          prepared[index].timeSeconds - prepared[peaks.last].timeSeconds <
              minimumInterval) {
        if (values[index] > values[peaks.last]) peaks[peaks.length - 1] = index;
      } else {
        peaks.add(index);
      }
    }
    if (peaks.length < 2) return 0;
    final intervals = <double>[];
    for (var index = 1; index < peaks.length; index++) {
      final interval =
          prepared[peaks[index]].timeSeconds -
          prepared[peaks[index - 1]].timeSeconds;
      if (interval >= minimumInterval && interval <= maximumInterval) {
        intervals.add(interval);
      }
    }
    if (intervals.isEmpty) return 0;
    intervals.sort();
    final middle = intervals.length ~/ 2;
    final median = intervals.length.isOdd
        ? intervals[middle]
        : (intervals[middle - 1] + intervals[middle]) / 2;
    return median <= 0 ? 0 : 60.0 / median;
  }

  double _slopeCountRateInWindow(double windowSeconds) {
    final prepared = _preparedSeries(windowSeconds);
    if (prepared.length < slopeWindow) return 0;
    final smoothed = <TimedValue>[];
    for (var index = 0; index < prepared.length; index++) {
      final start = math.max(0, index - smoothWindow + 1);
      final part = prepared.sublist(start, index + 1);
      final average =
          part.fold<double>(0, (total, item) => total + item.value) /
          part.length;
      smoothed.add(TimedValue(prepared[index].timeSeconds, average));
    }

    var state = BreathState.exhale;
    var events = 0;
    for (var index = 1; index < smoothed.length; index++) {
      final start = math.max(0, index - slopeWindow + 1);
      final slope = _slopeOfLast(
        smoothed.sublist(start, index + 1),
        slopeWindow,
      );
      var newState = state;
      if (slope > slopeDeadband) {
        newState = BreathState.exhale;
      } else if (slope < -slopeDeadband) {
        newState = BreathState.inhale;
      }
      if (state == BreathState.exhale && newState == BreathState.inhale) {
        final amplitudeStart = math.max(0, index - 120);
        final local = prepared
            .sublist(amplitudeStart, index + 1)
            .map((item) => item.value)
            .toList();
        if (local.length > 1 &&
            local.reduce(math.max) - local.reduce(math.min) >= noiseThreshold) {
          events++;
        }
      }
      state = newState;
    }
    if (events == 0) return 0;
    final duration = prepared.last.timeSeconds - prepared.first.timeSeconds;
    return duration <= 0 ? 0 : events * 60.0 / duration;
  }

  double _slopeOfLast(List<TimedValue> values, int window) {
    if (values.length < 2) return 0;
    final start = math.max(0, values.length - window);
    final selected = values.sublist(start);
    final n = selected.length.toDouble();
    double sumX = 0;
    double sumY = 0;
    double sumXY = 0;
    double sumX2 = 0;
    for (var index = 0; index < selected.length; index++) {
      final x = index.toDouble();
      final y = selected[index].value;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumX2 += x * x;
    }
    final denominator = n * sumX2 - sumX * sumX;
    return denominator.abs() < 1e-12
        ? 0
        : (n * sumXY - sumX * sumY) / denominator;
  }

  void _appendRaw(double timeSeconds, double value) {
    _rawValues.addLast(TimedValue(timeSeconds, value));
    _trimTimedQueue(_rawValues, timeSeconds, maximumAnalysisWindowSeconds);
  }

  void _trimTimedQueue(
    Queue<TimedValue> queue,
    double nowSeconds,
    double durationSeconds,
  ) {
    final minimum = nowSeconds - durationSeconds;
    while (queue.isNotEmpty && queue.first.timeSeconds < minimum) {
      queue.removeFirst();
    }
  }

  void _appendPlotPoint(List<FlSpot> target, FlSpot point) {
    target.add(point);
    while (target.length > maxPoints ||
        (target.isNotEmpty && point.x - target.first.x > chartWindowSeconds)) {
      target.removeAt(0);
    }
  }

  void _recordBreath(DateTime now) {
    if (_inhaleTimestamps.isNotEmpty &&
        now.difference(_inhaleTimestamps.last).inMilliseconds < 1200) {
      return;
    }
    _inhaleTimestamps.addLast(now);
    _trimInhaleHistory(now);
  }

  void _trimInhaleHistory(DateTime now) {
    final minimum = now.subtract(const Duration(seconds: rrHistorySeconds));
    while (_inhaleTimestamps.isNotEmpty &&
        _inhaleTimestamps.first.isBefore(minimum)) {
      _inhaleTimestamps.removeFirst();
    }
  }

  void _updateSegmentsAndState(
    double timeSeconds,
    DateTime receivedAt,
    BreathState newState,
  ) {
    if (newState != currentState || segments.isEmpty) {
      segments.add(
        StateSegment(startX: timeSeconds, endX: timeSeconds, state: newState),
      );
      if (newState != currentState) {
        _transitionTimestamps.addLast(receivedAt);
      }
    } else {
      segments.last.endX = timeSeconds;
    }
    currentState = newState;
    final transitionMinimum = receivedAt.subtract(const Duration(seconds: 15));
    while (_transitionTimestamps.isNotEmpty &&
        _transitionTimestamps.first.isBefore(transitionMinimum)) {
      _transitionTimestamps.removeFirst();
    }
    recentTransitions = _transitionTimestamps.length;

    final minimumX = math.max(0.0, timeSeconds - chartWindowSeconds);
    while (segments.isNotEmpty && segments.first.endX < minimumX) {
      segments.removeAt(0);
    }
    if (segments.isNotEmpty && segments.first.startX < minimumX) {
      segments.first.startX = minimumX;
    }
  }

  void clear() {
    _rawValues.clear();
    _filteredHistory.clear();
    _phaseMeans.clear();
    _inhaleTimestamps.clear();
    _transitionTimestamps.clear();
    spots.clear();
    rawSpots.clear();
    humiditySpots.clear();
    segments.clear();
    currentState = BreathState.exhale;
    recentTransitions = 0;
    currentSlope = 0;
    phaseThreshold = 0;
    filteredValue = 0;
  }
}

// ==========================================
// KONTROLER BLE (Główny Hub Zarządzający)
// ==========================================

class BreathController extends ChangeNotifier {
  BluetoothDevice? _device;
  StreamSubscription<List<int>>? _notifySub;
  String status = 'Rozłączono';
  bool isConnecting = false;

  bool get isConnected => _device != null;

  final Stopwatch _sampleClock = Stopwatch();
  double _x = 0;
  SensorSample? latestSample;

  final ChannelAnalyzer mouth = ChannelAnalyzer.temperature();
  final ChannelAnalyzer right = ChannelAnalyzer.temperature();
  final ChannelAnalyzer left = ChannelAnalyzer.temperature();
  final ChannelAnalyzer belt = ChannelAnalyzer.belt();

  BreathingRoute activeRoute = BreathingRoute.nose;
  BreathState mainState = BreathState.exhale;
  String activeNostril = 'prawe nozdrze';
  int routeMouthCycles = 0;
  int routeNoseCycles = 0;
  double routeConfidence = 0;
  final Queue<TimedRouteVote> _routeVotes = ListQueue();
  DateTime? _lastRouteVoteAt;
  DateTime? _lastRouteSwitchAt;
  bool _useRightNostril = true;
  Timer? _metronomeTimer;
  int metronomeRate = 0;
  BreathState metronomeState = BreathState.inhale;

  static const Duration _temperatureRrUpdateInterval = Duration(seconds: 2);
  static const int _temperatureRrMedianSamples = 5;
  final Queue<double> _temperatureRrCandidates = ListQueue();
  DateTime? _lastTemperatureRrUpdateAt;
  double _stableTemperatureRr = 0;

  BreathController() {
    unawaited(_restoreSettings());
  }

  // --- WYBÓR URZĄDZENIA ---
  DeviceType currentDeviceType = DeviceType.mask;
  RrWindowMode rrWindowMode = RrWindowMode.tenSeconds;

  int get rrWindowSeconds => rrWindowMode.seconds;

  void setRrWindowMode(RrWindowMode mode) {
    if (rrWindowMode == mode) return;
    rrWindowMode = mode;
    _resetTemperatureRrStabilizer();
    unawaited(_saveWindowSetting());
    notifyListeners();
  }

  Future<void> _restoreSettings() async {
    final preferences = await SharedPreferences.getInstance();
    final storedSeconds = preferences.getInt('rr_window_seconds');
    if (storedSeconds == 20) rrWindowMode = RrWindowMode.twentySeconds;
    notifyListeners();
  }

  Future<void> _saveWindowSetting() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setInt('rr_window_seconds', rrWindowSeconds);
  }

  void setDeviceType(DeviceType type) {
    currentDeviceType = type;
    if (type == DeviceType.tensometricBelt) {
      belt.simpleSensitivity = 0.25;
    } else if (type == DeviceType.barometricBelt) {
      belt.simpleSensitivity = 0.0002;
    }
    clearData(full: false);
    notifyListeners();
  }

  String get targetDeviceName {
    switch (currentDeviceType) {
      case DeviceType.mask:
        return 'ESP32S3_BME280_4x';
      case DeviceType.tensometricBelt:
        return 'Pas_Tensometryczny';
      case DeviceType.barometricBelt:
        return 'Pas_Barometryczny';
    }
  }

  // -- APNEA STATE --
  bool isApneaMonitoringEnabled = false;
  bool isApneaCurrentlyDetected = false;
  int currentApneaDuration = 0;
  DateTime? _currentApneaStart;

  // -- SESJE BADAŃ --
  bool isSessionActive = false;
  DateTime? sessionStartTime;
  final List<double> _sessionRrSamples = [];
  final List<ApneaEvent> _sessionApneaEvents = [];
  final List<SessionDataPoint> _sessionWaveform = [];
  int _sessionMouthTicks = 0;
  int _sessionNoseTicks = 0;
  DateTime? _lastSessionRateAt;
  DateTime? _lastWaveformAt;
  bool lastSaveWasSynced = false;

  ChannelAnalyzer get activeNoseAnalyzer {
    activeNostril = _useRightNostril ? 'prawe nozdrze' : 'lewe nozdrze';
    return _useRightNostril ? right : left;
  }

  ChannelAnalyzer get activeAnalyzer {
    if (currentDeviceType != DeviceType.mask) return belt;
    return activeRoute == BreathingRoute.mouth ? mouth : activeNoseAnalyzer;
  }

  double get currentRr => currentDeviceType == DeviceType.mask
      ? _stableTemperatureRr
      : activeAnalyzer.respiratoryRateInWindow(rrWindowSeconds);
  String get activeFilterName => activeAnalyzer.filterName;
  String get activeEstimatorName => activeAnalyzer.estimatorName;
  int get apneaEventsCount =>
      _sessionApneaEvents.length + (isApneaCurrentlyDetected ? 1 : 0);

  double? get metronomeError {
    if (metronomeRate == 0 || currentRr <= 0) return null;
    return currentRr - metronomeRate;
  }

  void setMetronomeRate(int rate) {
    _metronomeTimer?.cancel();
    metronomeRate = rate;
    metronomeState = BreathState.inhale;
    if (rate > 0) {
      SystemSound.play(SystemSoundType.click);
      final halfCycle = Duration(milliseconds: (30000 / rate).round());
      _metronomeTimer = Timer.periodic(halfCycle, (_) {
        metronomeState = metronomeState == BreathState.inhale
            ? BreathState.exhale
            : BreathState.inhale;
        SystemSound.play(SystemSoundType.click);
        notifyListeners();
      });
    }
    notifyListeners();
  }

  void toggleApneaMonitoring(bool value) {
    isApneaMonitoringEnabled = value;
    if (!value) {
      isApneaCurrentlyDetected = false;
      currentApneaDuration = 0;
      _currentApneaStart = null;
    }
    notifyListeners();
  }

  void startSession() {
    isSessionActive = true;
    sessionStartTime = DateTime.now();
    _sessionRrSamples.clear();
    _sessionApneaEvents.clear();
    _sessionWaveform.clear();
    _sessionMouthTicks = 0;
    _sessionNoseTicks = 0;
    _lastSessionRateAt = null;
    _lastWaveformAt = null;
    lastSaveWasSynced = false;
    isApneaCurrentlyDetected = false;
    currentApneaDuration = 0;
    _currentApneaStart = null;
    notifyListeners();
  }

  Future<SessionRecord?> stopSession({String? cloudPatientId}) async {
    if (!isSessionActive || sessionStartTime == null) return null;
    isSessionActive = false;
    if (isApneaCurrentlyDetected && _currentApneaStart != null) {
      _sessionApneaEvents.add(
        ApneaEvent(
          startTime: _currentApneaStart!,
          durationSeconds: currentApneaDuration,
        ),
      );
    }

    double avgRr = 0.0;
    if (_sessionRrSamples.isNotEmpty) {
      avgRr =
          _sessionRrSamples.reduce((a, b) => a + b) / _sessionRrSamples.length;
    }

    double mPerc = 0.0;
    double nPerc = 0.0;
    int totalTicks = _sessionMouthTicks + _sessionNoseTicks;
    if (totalTicks > 0) {
      mPerc = (_sessionMouthTicks / totalTicks) * 100;
      nPerc = (_sessionNoseTicks / totalTicks) * 100;
    }

    final record = SessionRecord(
      startTime: sessionStartTime!,
      endTime: DateTime.now(),
      avgRr: avgRr,
      apneaMonitored: isApneaMonitoringEnabled,
      apneaEvents: List.from(_sessionApneaEvents),
      mouthPercentage: mPerc,
      nosePercentage: nPerc,
      waveform: List.from(_sessionWaveform),
      deviceType: currentDeviceType.toString(),
    );

    final storedRecord = await LocalSessionStore.save(record);
    lastSaveWasSynced = false;
    if (cloudPatientId != null && await FirebaseBootstrap.initialize()) {
      try {
        await FirebaseFirestore.instance
            .collection('patients')
            .doc(cloudPatientId)
            .collection('sessions')
            .add(record.toMap());
        lastSaveWasSynced = true;
      } catch (error) {
        debugPrint('Sesja pozostała lokalnie, synchronizacja nieudana: $error');
      }
    }

    sessionStartTime = null;
    isApneaCurrentlyDetected = false;
    currentApneaDuration = 0;
    _currentApneaStart = null;
    notifyListeners();
    return storedRecord;
  }

  Future<bool> _requestPermissions() async {
    if (!Platform.isAndroid) return true;
    final statuses = await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
    final scanOk = statuses[Permission.bluetoothScan]?.isGranted ?? false;
    final connectOk = statuses[Permission.bluetoothConnect]?.isGranted ?? false;
    final locationStatus =
        statuses[Permission.locationWhenInUse] ?? PermissionStatus.granted;
    return scanOk &&
        connectOk &&
        (locationStatus.isGranted ||
            locationStatus.isLimited ||
            locationStatus.isRestricted);
  }

  Future<void> connectFlow() async {
    if (isConnecting) return;
    isConnecting = true;
    status = 'Szukanie...';
    notifyListeners();

    try {
      final ok = await _requestPermissions();
      if (!ok) {
        status = 'Brak uprawnień';
        isConnecting = false;
        notifyListeners();
        return;
      }

      if (Platform.isAndroid) await FlutterBluePlus.turnOn();
      await FlutterBluePlus.adapterState
          .where((state) => state == BluetoothAdapterState.on)
          .first;

      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 8));

      BluetoothDevice? foundDevice;
      var sub = FlutterBluePlus.onScanResults.listen((results) {
        for (final r in results) {
          if (r.device.platformName == targetDeviceName ||
              r.advertisementData.advName == targetDeviceName) {
            foundDevice = r.device;
            FlutterBluePlus.stopScan();
            break;
          }
        }
      });

      await Future.delayed(const Duration(seconds: 9));
      await sub.cancel();
      if (foundDevice == null) {
        status = 'Nie znaleziono urządzenia';
        isConnecting = false;
        notifyListeners();
        return;
      }

      status = 'Łączenie...';
      notifyListeners();
      await foundDevice!.connect(
        timeout: const Duration(seconds: 5),
        autoConnect: false,
      );
      _device = foundDevice;

      final services = await _device!.discoverServices();
      BluetoothCharacteristic? targetChar;
      for (final service in services) {
        if (service.uuid.str.toLowerCase() == serviceUuid.toLowerCase()) {
          for (final c in service.characteristics) {
            if (c.uuid.str.toLowerCase() == characteristicUuid.toLowerCase()) {
              targetChar = c;
              break;
            }
          }
        }
      }

      if (targetChar == null) {
        status = 'Błąd usługi';
        isConnecting = false;
        notifyListeners();
        return;
      }

      _notifySub = targetChar.lastValueStream.listen(_onDataReceived);
      _device!.cancelWhenDisconnected(_notifySub!);
      await targetChar.setNotifyValue(true);

      status = 'Połączono';
      isConnecting = false;

      // Czyszczenie danych na starcie
      clearData(full: false);
      notifyListeners();
    } catch (e) {
      status = 'Błąd połączenia';
      isConnecting = false;
      notifyListeners();
    }
  }

  void _onDataReceived(List<int> value) {
    if (value.isEmpty) return;
    final text = utf8.decode(value, allowMalformed: true).trim();
    if (!_sampleClock.isRunning) _sampleClock.start();
    _x = _sampleClock.elapsedMicroseconds / 1000000.0;
    final receivedAt = DateTime.now();

    if (currentDeviceType == DeviceType.mask) {
      final sample = SensorSample.fromCsv(text);
      if (sample == null) return;
      latestSample = sample;

      mouth.processTemperature(
        _x,
        receivedAt,
        sample.tempMouth,
        sample.humMouth,
        sample.t0,
        analysisWindowSeconds: rrWindowSeconds,
      );
      right.processTemperature(
        _x,
        receivedAt,
        sample.tempRight,
        sample.humRight,
        sample.t1,
        analysisWindowSeconds: rrWindowSeconds,
      );
      left.processTemperature(
        _x,
        receivedAt,
        sample.tempLeft,
        sample.humLeft,
        sample.t2,
        analysisWindowSeconds: rrWindowSeconds,
      );

      _updateBreathingRoute(receivedAt);
      _updateStableTemperatureRr(receivedAt);

      if (isSessionActive) {
        if (activeRoute == BreathingRoute.mouth) {
          _sessionMouthTicks++;
        } else {
          _sessionNoseTicks++;
        }
        final nasalTemperature = activeNoseAnalyzer.currentTemp;
        _captureSessionPoint(
          receivedAt,
          mouthTemperature: sample.tempMouth,
          noseTemperature: nasalTemperature,
        );
      }
    } else {
      double? raw = double.tryParse(text);
      if (raw != null && raw.isFinite) {
        belt.processBelt(
          _x,
          receivedAt,
          raw,
          analysisWindowSeconds: rrWindowSeconds,
        );
        mainState = belt.currentState;
        activeRoute = BreathingRoute.nose;

        if (isSessionActive) {
          _sessionNoseTicks++;
          _captureSessionPoint(
            receivedAt,
            mouthTemperature: 0,
            noseTemperature: belt.filteredValue,
          );
        }
      }
    }

    if (isApneaMonitoringEnabled) _checkApnea();
    notifyListeners();
  }

  void _updateStableTemperatureRr(DateTime now) {
    if (_lastTemperatureRrUpdateAt != null &&
        now.difference(_lastTemperatureRrUpdateAt!) <
            _temperatureRrUpdateInterval) {
      return;
    }
    _lastTemperatureRrUpdateAt = now;

    final candidate = activeAnalyzer.respiratoryRateInWindow(rrWindowSeconds);
    if (!candidate.isFinite || candidate < 4 || candidate > 45) return;

    _temperatureRrCandidates.addLast(candidate);
    while (_temperatureRrCandidates.length > _temperatureRrMedianSamples) {
      _temperatureRrCandidates.removeFirst();
    }

    final sorted = _temperatureRrCandidates.toList()..sort();
    final middle = sorted.length ~/ 2;
    final median = sorted.length.isOdd
        ? sorted[middle]
        : (sorted[middle - 1] + sorted[middle]) / 2;

    if (_stableTemperatureRr <= 0) {
      _stableTemperatureRr = median;
      return;
    }

    _stableTemperatureRr = 0.65 * _stableTemperatureRr + 0.35 * median;
    if ((_stableTemperatureRr - median).abs() < 0.05) {
      _stableTemperatureRr = median;
    }
  }

  void _resetTemperatureRrStabilizer() {
    _temperatureRrCandidates.clear();
    _lastTemperatureRrUpdateAt = null;
    _stableTemperatureRr = 0;
  }

  void _captureSessionPoint(
    DateTime now, {
    required double mouthTemperature,
    required double noseTemperature,
  }) {
    if (_lastSessionRateAt == null ||
        now.difference(_lastSessionRateAt!).inMilliseconds >= 1000) {
      final rr = currentRr;
      if (rr > 0 && rr <= 60) _sessionRrSamples.add(rr);
      _lastSessionRateAt = now;
    }
    if (_lastWaveformAt == null ||
        now.difference(_lastWaveformAt!).inMilliseconds >= 250) {
      _sessionWaveform.add(
        SessionDataPoint(
          time: now,
          mouthTemp: mouthTemperature.isFinite ? mouthTemperature : 0,
          noseTemp: noseTemperature.isFinite ? noseTemperature : 0,
        ),
      );
      _lastWaveformAt = now;
    }
  }

  void _checkApnea() {
    DateTime? lastMouth = mouth.lastBreathTime;
    DateTime? lastNose;

    DateTime? lastBreath;
    if (currentDeviceType == DeviceType.mask) {
      final lastRight = right.lastBreathTime;
      final lastLeft = left.lastBreathTime;
      if (lastRight != null && lastLeft != null) {
        lastNose = lastRight.isAfter(lastLeft) ? lastRight : lastLeft;
      } else {
        lastNose = lastRight ?? lastLeft;
      }
      if (lastMouth != null && lastNose != null) {
        lastBreath = lastMouth.isAfter(lastNose) ? lastMouth : lastNose;
      } else {
        lastBreath = lastMouth ?? lastNose;
      }
    } else {
      lastBreath = belt.lastBreathTime;
    }

    if (lastBreath != null) {
      final secondsSinceLast = DateTime.now().difference(lastBreath).inSeconds;
      if (secondsSinceLast >= 10) {
        if (!isApneaCurrentlyDetected) {
          isApneaCurrentlyDetected = true;
          _currentApneaStart = lastBreath;
        }
        currentApneaDuration = secondsSinceLast;
      } else {
        if (isApneaCurrentlyDetected) {
          if (isSessionActive && _currentApneaStart != null) {
            _sessionApneaEvents.add(
              ApneaEvent(
                startTime: _currentApneaStart!,
                durationSeconds: currentApneaDuration,
              ),
            );
          }
          isApneaCurrentlyDetected = false;
          currentApneaDuration = 0;
          _currentApneaStart = null;
        }
      }
    }
  }

  void _updateBreathingRoute(DateTime now) {
    final rightQuality = right.signalQuality(20, nowSeconds: _x);
    final leftQuality = left.signalQuality(20, nowSeconds: _x);
    if (_useRightNostril && leftQuality > rightQuality * 1.20) {
      _useRightNostril = false;
    } else if (!_useRightNostril && rightQuality > leftQuality * 1.20) {
      _useRightNostril = true;
    }
    final nasalAnalyzer = _useRightNostril ? right : left;
    activeNostril = _useRightNostril ? 'prawe nozdrze' : 'lewe nozdrze';
    mainState = activeRoute == BreathingRoute.mouth
        ? mouth.currentState
        : nasalAnalyzer.currentState;

    if (_lastRouteVoteAt != null &&
        now.difference(_lastRouteVoteAt!).inMilliseconds < 500) {
      return;
    }
    _lastRouteVoteAt = now;

    const evidenceWindow = Duration(seconds: 20);
    routeMouthCycles = mouth.recentBreathCount(evidenceWindow, now: now);
    routeNoseCycles = math.max(
      right.recentBreathCount(evidenceWindow, now: now),
      left.recentBreathCount(evidenceWindow, now: now),
    );
    final mouthQuality = mouth.signalQuality(20, nowSeconds: _x);
    final noseQuality = math.max(rightQuality, leftQuality);
    final mouthScore = routeMouthCycles + 0.35 * mouthQuality;
    final noseScore = routeNoseCycles + 0.35 * noseQuality;

    BreathingRoute? candidate;
    if (mouthScore >= noseScore + 0.75 && mouthQuality >= 1) {
      candidate = BreathingRoute.mouth;
    } else if (noseScore >= mouthScore + 0.75 && noseQuality >= 1) {
      candidate = BreathingRoute.nose;
    } else if (mouthQuality >= 1 && mouthQuality > noseQuality * 1.50) {
      candidate = BreathingRoute.mouth;
    } else if (noseQuality >= 1 && noseQuality > mouthQuality * 1.50) {
      candidate = BreathingRoute.nose;
    }

    if (candidate != null) _routeVotes.addLast(TimedRouteVote(now, candidate));
    final voteStart = now.subtract(const Duration(seconds: 8));
    while (_routeVotes.isNotEmpty &&
        _routeVotes.first.time.isBefore(voteStart)) {
      _routeVotes.removeFirst();
    }
    final mouthVotes = _routeVotes
        .where((vote) => vote.route == BreathingRoute.mouth)
        .length;
    final noseVotes = _routeVotes.length - mouthVotes;
    final winningVotes = math.max(mouthVotes, noseVotes);
    routeConfidence = _routeVotes.isEmpty
        ? 0
        : winningVotes / _routeVotes.length;

    if (_routeVotes.length >= 8 && routeConfidence >= 0.70) {
      final votedRoute = mouthVotes > noseVotes
          ? BreathingRoute.mouth
          : BreathingRoute.nose;
      final canSwitch =
          _lastRouteSwitchAt == null ||
          now.difference(_lastRouteSwitchAt!).inSeconds >= 4;
      if (votedRoute != activeRoute && canSwitch) {
        activeRoute = votedRoute;
        _lastRouteSwitchAt = now;
      }
    }
    mainState = activeRoute == BreathingRoute.mouth
        ? mouth.currentState
        : nasalAnalyzer.currentState;
  }

  void clearData({bool full = true}) {
    _sampleClock
      ..stop()
      ..reset();
    if (isConnected) _sampleClock.start();
    _x = 0;
    latestSample = null;
    mouth.clear();
    right.clear();
    left.clear();
    belt.clear();
    _routeVotes.clear();
    _lastRouteVoteAt = null;
    _lastRouteSwitchAt = null;
    routeMouthCycles = 0;
    routeNoseCycles = 0;
    routeConfidence = 0;
    activeNostril = 'prawe nozdrze';
    _useRightNostril = true;
    activeRoute = BreathingRoute.nose;
    mainState = BreathState.exhale;
    _resetTemperatureRrStabilizer();
    isApneaCurrentlyDetected = false;
    currentApneaDuration = 0;
    _currentApneaStart = null;
    if (full) notifyListeners();
  }

  Future<void> disconnect() async {
    await _notifySub?.cancel();
    await _device?.disconnect();
    _device = null;
    status = 'Rozłączono';
    clearData();
  }

  Future<void> reconnect() async {
    await disconnect();
    connectFlow();
  }

  @override
  void dispose() {
    _metronomeTimer?.cancel();
    _notifySub?.cancel();
    _device?.disconnect();
    super.dispose();
  }
}

// ==========================================
// WARSTWA UI APLIKACJI
// ==========================================

class NoseApp extends StatelessWidget {
  const NoseApp({super.key});
  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF006B5E),
      brightness: Brightness.light,
      surface: Colors.white,
    );
    return MaterialApp(
      title: 'NOSE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: colorScheme,
        scaffoldBackgroundColor: const Color(0xFFF5F7F7),
        appBarTheme: AppBarTheme(
          backgroundColor: const Color(0xFFF5F7F7),
          foregroundColor: colorScheme.onSurface,
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            color: colorScheme.onSurface,
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Color(0xFFD8E0DF)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Color(0xFFD8E0DF)),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(48, 48),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: colorScheme.primaryContainer,
          height: 68,
        ),
      ),
      home: PatientMonitorPage(patient: PatientProfile.offline()),
    );
  }
}

// --- EKRAN LOGOWANIA ---
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  static const _clinicianLogin = String.fromEnvironment('NOSE_CLINICIAN_LOGIN');
  static const _clinicianPassword = String.fromEnvironment(
    'NOSE_CLINICIAN_PASSWORD',
  );

  final _loginController = TextEditingController();
  final _passController = TextEditingController();
  bool _isLoading = false;

  Future<void> _handleLogin() async {
    final login = _loginController.text.trim();
    final pass = _passController.text.trim();
    if (login.isEmpty || pass.isEmpty) return;

    setState(() => _isLoading = true);
    try {
      final firebaseAvailable = await FirebaseBootstrap.initialize();
      if (!firebaseAvailable) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Usługa online jest teraz niedostępna. Tryb lokalny nadal działa.',
            ),
          ),
        );
        return;
      }
      if (_clinicianLogin.isNotEmpty &&
          _clinicianPassword.isNotEmpty &&
          login == _clinicianLogin &&
          pass == _clinicianPassword) {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const DoctorDashboardPage()),
        );
        return;
      }

      final snapshot = await FirebaseFirestore.instance
          .collection('patients')
          .where('login', isEqualTo: login)
          .where('password', isEqualTo: pass)
          .limit(1)
          .get();
      if (snapshot.docs.isNotEmpty) {
        final patient = PatientProfile.fromMap(
          snapshot.docs.first.id,
          snapshot.docs.first.data(),
        );
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) =>
                PatientMonitorPage(patient: patient, isCloudAccount: true),
          ),
        );
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Błędny login lub hasło!')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Błąd połączenia z bazą: $e')));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _openOfflineMode() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => PatientMonitorPage(patient: PatientProfile.offline()),
      ),
    );
  }

  @override
  void dispose() {
    _loginController.dispose();
    _passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Konto online'),
        leading: IconButton(
          tooltip: 'Wróć do trybu lokalnego',
          icon: const Icon(Icons.arrow_back),
          onPressed: _openOfflineMode,
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.cloud_outlined,
                size: 56,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 20),
              const Text(
                'Synchronizacja NOSE',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 32),
              TextField(
                controller: _loginController,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.person_outline),
                  labelText: 'Login',
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passController,
                obscureText: true,
                onSubmitted: (_) => _isLoading ? null : _handleLogin(),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.lock_outline),
                  labelText: 'Hasło',
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _isLoading ? null : _handleLogin,
                  icon: _isLoading
                      ? const SizedBox.square(
                          dimension: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.login),
                  label: const Text('Zaloguj'),
                ),
              ),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: _openOfflineMode,
                icon: const Icon(Icons.phone_android),
                label: const Text('Używaj bez konta'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// EKRAN WYKRESU BEZDECHU (HOLTER)
// ==========================================
class ApneaChartPage extends StatelessWidget {
  final ApneaEvent event;
  final SessionRecord session;

  const ApneaChartPage({super.key, required this.event, required this.session});

  @override
  Widget build(BuildContext context) {
    final startTime = event.startTime.subtract(const Duration(seconds: 10));
    final endTime = event.startTime.add(
      Duration(seconds: event.durationSeconds + 10),
    );
    final snippet = session.waveform
        .where((p) => p.time.isAfter(startTime) && p.time.isBefore(endTime))
        .toList();

    List<FlSpot> noseSpots = [];
    List<FlSpot> mouthSpots = [];
    double minY = 1000000;
    double maxY = -1000000;

    if (snippet.isNotEmpty) {
      final firstTime = snippet.first.time;
      for (var p in snippet) {
        final sec = p.time.difference(firstTime).inMilliseconds / 1000.0;
        noseSpots.add(FlSpot(sec, p.noseTemp));
        if (session.deviceType == DeviceType.mask.toString()) {
          mouthSpots.add(FlSpot(sec, p.mouthTemp));
        }

        if (p.noseTemp < minY) minY = p.noseTemp;
        if (p.mouthTemp < minY &&
            session.deviceType == DeviceType.mask.toString()) {
          minY = p.mouthTemp;
        }
        if (p.noseTemp > maxY) maxY = p.noseTemp;
        if (p.mouthTemp > maxY &&
            session.deviceType == DeviceType.mask.toString()) {
          maxY = p.mouthTemp;
        }
      }
    }

    if (minY == 1000000) minY = 0;
    if (maxY == -1000000) maxY = 10;

    // Dynamiczny margines
    double pad = (maxY - minY) * 0.1;
    if (pad == 0) pad = 1.0;
    minY -= pad;
    maxY += pad;

    double apneaStartX = 10.0;
    double apneaEndX = 10.0 + event.durationSeconds;

    return Scaffold(
      appBar: AppBar(title: const Text('Weryfikacja Incydentu')),
      body: snippet.isEmpty
          ? const Center(
              child: Text('Brak zapisanego sygnału dla tego zdarzenia.'),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          const Row(
                            children: [
                              Icon(
                                Icons.warning_amber_rounded,
                                color: Colors.red,
                              ),
                              SizedBox(width: 8),
                              Text(
                                'Szczegóły zdarzenia',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Czas trwania:',
                                style: TextStyle(color: Colors.black54),
                              ),
                              Text(
                                '${event.durationSeconds} sek.',
                                style: const TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 18,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Zatrzymanie oddechu:',
                                style: TextStyle(color: Colors.black54),
                              ),
                              Text(
                                '${event.startTime.hour.toString().padLeft(2, '0')}:${event.startTime.minute.toString().padLeft(2, '0')}:${event.startTime.second.toString().padLeft(2, '0')}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Zapis krzywej oddechowej',
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF0F4C81),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Czerwona strefa oznacza czas trwania bezdechu',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: LineChart(
                          LineChartData(
                            minX: 0,
                            maxX: noseSpots.isNotEmpty ? noseSpots.last.x : 20,
                            minY: minY,
                            maxY: maxY,
                            rangeAnnotations: RangeAnnotations(
                              verticalRangeAnnotations: [
                                VerticalRangeAnnotation(
                                  x1: apneaStartX,
                                  x2: apneaEndX,
                                  color: Colors.red.withValues(alpha: 0.15),
                                ),
                              ],
                            ),
                            lineBarsData: [
                              LineChartBarData(
                                spots: noseSpots,
                                isCurved: true,
                                barWidth: 2,
                                color: Colors.blue,
                                dotData: const FlDotData(show: false),
                              ),
                              if (session.deviceType ==
                                  DeviceType.mask.toString())
                                LineChartBarData(
                                  spots: mouthSpots,
                                  isCurved: true,
                                  barWidth: 2,
                                  color: Colors.redAccent,
                                  dotData: const FlDotData(show: false),
                                ),
                            ],
                            titlesData: const FlTitlesData(
                              topTitles: AxisTitles(
                                sideTitles: SideTitles(showTitles: false),
                              ),
                              rightTitles: AxisTitles(
                                sideTitles: SideTitles(showTitles: false),
                              ),
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(showTitles: false),
                              ),
                            ),
                            gridData: const FlGridData(
                              show: true,
                              drawVerticalLine: false,
                            ),
                            borderData: FlBorderData(
                              show: true,
                              border: Border.all(
                                color: const Color(0xFFE8ECF3),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 12,
                        height: 12,
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        session.deviceType == DeviceType.mask.toString()
                            ? 'Nos'
                            : 'Sygnał z pasa',
                      ),
                      if (session.deviceType == DeviceType.mask.toString()) ...[
                        const SizedBox(width: 16),
                        Container(
                          width: 12,
                          height: 12,
                          decoration: const BoxDecoration(
                            color: Colors.redAccent,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        const Text('Usta'),
                      ],
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
    );
  }
}

// ==========================================
// SZCZEGÓŁY SESJI BADANIA
// ==========================================
class SessionDetailsPage extends StatelessWidget {
  final String patientId;
  final SessionRecord session;
  final bool isDoctor;
  final bool isLocal;

  const SessionDetailsPage({
    super.key,
    required this.patientId,
    required this.session,
    required this.isDoctor,
    this.isLocal = false,
  });

  @override
  Widget build(BuildContext context) {
    String pad(int n) => n.toString().padLeft(2, '0');
    String dateStr =
        '${pad(session.startTime.day)}.${pad(session.startTime.month)}.${session.startTime.year}';
    String timeStr =
        '${pad(session.startTime.hour)}:${pad(session.startTime.minute)}';
    String endStr =
        '${pad(session.endTime.hour)}:${pad(session.endTime.minute)}';
    String durStr =
        '${session.duration.inMinutes}m ${session.duration.inSeconds.remainder(60)}s';

    bool isMask = session.deviceType == DeviceType.mask.toString();
    String deviceLabel = 'Maska NOSOWA (Wielokanałowa)';
    if (session.deviceType == DeviceType.tensometricBelt.toString()) {
      deviceLabel = 'Pas Tensometryczny';
    }
    if (session.deviceType == DeviceType.barometricBelt.toString()) {
      deviceLabel = 'Pas Barometryczny';
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Szczegóły Badania'),
        actions: [
          if ((isDoctor || isLocal) && session.id != null)
            IconButton(
              tooltip: 'Usuń badanie',
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Usuń badanie'),
                    content: Text(
                      isLocal
                          ? 'Czy na pewno usunąć to badanie z urządzenia?'
                          : 'Czy na pewno usunąć to badanie z chmury?',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text(
                          'Anuluj',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,
                          foregroundColor: Colors.white,
                        ),
                        onPressed: () async {
                          Navigator.pop(ctx);
                          if (isLocal) {
                            await LocalSessionStore.delete(session.id!);
                          } else {
                            await FirebaseFirestore.instance
                                .collection('patients')
                                .doc(patientId)
                                .collection('sessions')
                                .doc(session.id)
                                .delete();
                          }
                          if (context.mounted) Navigator.pop(context);
                        },
                        child: const Text('Usuń'),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Data Badania',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            dateStr,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 18,
                              color: Color(0xFF0F4C81),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            'Czas trwania',
                            style: TextStyle(
                              color: Colors.black54,
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            durStr,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 18,
                              color: Color(0xFF0F4C81),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const Divider(height: 32),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Start: $timeStr',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      Text(
                        'Koniec: $endStr',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isMask ? 'Dominujący tor oddechowy' : 'Metoda Badania',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (isMask) ...[
                    Row(
                      children: [
                        Expanded(
                          flex: math.max(1, session.nosePercentage.round()),
                          child: Container(
                            height: 12,
                            decoration: const BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.horizontal(
                                left: Radius.circular(6),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: math.max(1, session.mouthPercentage.round()),
                          child: Container(
                            height: 12,
                            decoration: const BoxDecoration(
                              color: Colors.redAccent,
                              borderRadius: BorderRadius.horizontal(
                                right: Radius.circular(6),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 12,
                              height: 12,
                              decoration: const BoxDecoration(
                                color: Colors.blue,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'NOS: ${session.nosePercentage.toStringAsFixed(1)}%',
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text(
                              'USTA: ${session.mouthPercentage.toStringAsFixed(1)}%',
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              width: 12,
                              height: 12,
                              decoration: const BoxDecoration(
                                color: Colors.redAccent,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ] else ...[
                    Row(
                      children: [
                        const Icon(Icons.cable, color: Colors.teal),
                        const SizedBox(width: 12),
                        Text(
                          deviceLabel,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Colors.teal,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Icon(Icons.air, color: Colors.green, size: 32),
                        const SizedBox(height: 8),
                        Text(
                          session.avgRr.toStringAsFixed(1),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: Colors.green,
                          ),
                        ),
                        const Text(
                          'Średni RR',
                          style: TextStyle(fontSize: 11, color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.warning_amber_rounded,
                          color: Colors.redAccent,
                          size: 32,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          session.apneaEventsPerHour.toStringAsFixed(1),
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w800,
                            color: Colors.redAccent,
                          ),
                        ),
                        const Text(
                          'Incydenty / Godz.',
                          style: TextStyle(fontSize: 11, color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Padding(
            padding: EdgeInsets.only(left: 8, bottom: 12),
            child: Text(
              'SZCZEGÓŁOWE INCYDENTY BEZDECHU',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: Color(0xFF0F4C81),
                letterSpacing: 1.0,
              ),
            ),
          ),
          if (!session.apneaMonitored)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  'Monitorowanie bezdechu było wyłączone.',
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            )
          else if (session.apneaEvents.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  'Brak zarejestrowanych epizodów bezdechu.',
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            )
          else
            ...session.apneaEvents.asMap().entries.map((entry) {
              int index = entry.key + 1;
              ApneaEvent event = entry.value;
              String evTime =
                  '${pad(event.startTime.hour)}:${pad(event.startTime.minute)}:${pad(event.startTime.second)}';
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.red.withValues(alpha: 0.1),
                    child: Text(
                      '#$index',
                      style: const TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  title: const Text(
                    'Zatrzymanie oddechu',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  subtitle: Text(
                    'Start o: $evTime | Trwał: ${event.durationSeconds}s',
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: IconButton(
                    icon: const Icon(
                      Icons.show_chart,
                      color: Color(0xFF0F4C81),
                    ),
                    tooltip: 'Pokaż wykres',
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            ApneaChartPage(event: event, session: session),
                      ),
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}

// ==========================================
// KONTO LEKARZA
// ==========================================
class DoctorDashboardPage extends StatefulWidget {
  const DoctorDashboardPage({super.key});
  @override
  State<DoctorDashboardPage> createState() => _DoctorDashboardPageState();
}

class _DoctorDashboardPageState extends State<DoctorDashboardPage> {
  void _logout() => Navigator.pushReplacement(
    context,
    MaterialPageRoute(builder: (_) => const LoginPage()),
  );
  void _addPatient() => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const AddPatientPage()),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Panel Lekarza (Cloud)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.redAccent),
            onPressed: _logout,
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('patients').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Błąd pobierania bazy: ${snapshot.error}'),
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data!.docs;
          if (docs.isEmpty) {
            return const Center(
              child: Text(
                'Brak zarejestrowanych pacjentów w chmurze.',
                style: TextStyle(color: Colors.grey),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            itemBuilder: (ctx, i) {
              final p = PatientProfile.fromMap(
                docs[i].id,
                docs[i].data() as Map<String, dynamic>,
              );
              return Card(
                elevation: 0,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 8,
                  ),
                  leading: CircleAvatar(
                    backgroundColor: const Color(
                      0xFF0F4C81,
                    ).withValues(alpha: 0.1),
                    child: const Icon(Icons.person, color: Color(0xFF0F4C81)),
                  ),
                  title: Text(
                    p.fullName,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                  subtitle: Text(
                    'Login: ${p.login}',
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PatientDetailsPage(patient: p),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addPatient,
        backgroundColor: const Color(0xFF0F4C81),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.person_add),
        label: const Text('Dodaj Pacjenta'),
      ),
    );
  }
}

class AddPatientPage extends StatefulWidget {
  const AddPatientPage({super.key});
  @override
  State<AddPatientPage> createState() => _AddPatientPageState();
}

class _AddPatientPageState extends State<AddPatientPage> {
  final _loginCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  final _weightCtrl = TextEditingController();
  final _heightCtrl = TextEditingController();
  final _historyCtrl = TextEditingController();
  bool _isLoading = false;

  Future<void> _save() async {
    if (_loginCtrl.text.isEmpty ||
        _passCtrl.text.isEmpty ||
        _nameCtrl.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Wypełnij wymagane pola!')));
      return;
    }
    setState(() => _isLoading = true);
    try {
      await FirebaseFirestore.instance.collection('patients').add({
        'login': _loginCtrl.text.trim(),
        'password': _passCtrl.text.trim(),
        'fullName': _nameCtrl.text.trim(),
        'weight': double.tryParse(_weightCtrl.text) ?? 0.0,
        'height': double.tryParse(_heightCtrl.text) ?? 0.0,
        'medicalHistory': _historyCtrl.text.trim(),
      });
      if (!mounted) return;
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Błąd zapisu: $e')));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nowy Pacjent')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const Text(
            'Dane logowania (dla pacjenta)',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F4C81),
            ),
          ),
          const SizedBox(height: 8),
          TextField(controller: _loginCtrl, decoration: _inputDeco('Login')),
          const SizedBox(height: 12),
          TextField(controller: _passCtrl, decoration: _inputDeco('Hasło')),
          const Divider(height: 48),
          const Text(
            'Dane medyczne',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F4C81),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _nameCtrl,
            decoration: _inputDeco('Imię i Nazwisko'),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _weightCtrl,
                  keyboardType: TextInputType.number,
                  decoration: _inputDeco('Waga (kg)'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _heightCtrl,
                  keyboardType: TextInputType.number,
                  decoration: _inputDeco('Wzrost (cm)'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _historyCtrl,
            maxLines: 4,
            decoration: _inputDeco('Historia chorób i uwagi'),
          ),
          const SizedBox(height: 32),
          SizedBox(
            height: 56,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F4C81),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              onPressed: _isLoading ? null : _save,
              child: _isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text(
                      'ZAPISZ DO CHMURY',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDeco(String label) => InputDecoration(
    labelText: label,
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide.none,
    ),
  );
}

class PatientDetailsPage extends StatelessWidget {
  final PatientProfile patient;
  const PatientDetailsPage({super.key, required this.patient});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Karta Pacjenta')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.person,
                        size: 40,
                        color: Color(0xFF0F4C81),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Text(
                          patient.fullName,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const Divider(height: 32),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _Stat(label: 'Waga', val: '${patient.weight} kg'),
                      _Stat(label: 'Wzrost', val: '${patient.height} cm'),
                      _Stat(
                        label: 'BMI',
                        val: patient.height > 0
                            ? (patient.weight /
                                      math.pow(patient.height / 100, 2))
                                  .toStringAsFixed(1)
                            : '--',
                      ),
                    ],
                  ),
                  const Divider(height: 32),
                  const Text(
                    'Historia chorób:',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    patient.medicalHistory.isEmpty
                        ? 'Brak wpisów'
                        : patient.medicalHistory,
                    style: const TextStyle(fontSize: 15),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          const Padding(
            padding: EdgeInsets.only(left: 8, bottom: 12),
            child: Text(
              'ZREALIZOWANE BADANIA',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                color: Color(0xFF0F4C81),
                letterSpacing: 1.0,
              ),
            ),
          ),
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('patients')
                .doc(patient.id)
                .collection('sessions')
                .orderBy('startTime', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('Błąd bazy: ${snapshot.error}'));
              }
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              final docs = snapshot.data!.docs;
              if (docs.isEmpty) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32.0),
                    child: Text(
                      'Pacjent nie wykonał jeszcze badań.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                );
              }

              return Column(
                children: docs.map((doc) {
                  final session = SessionRecord.fromMap(
                    doc.id,
                    doc.data() as Map<String, dynamic>,
                  );
                  String pad(int n) => n.toString().padLeft(2, '0');
                  String dateStr =
                      '${pad(session.startTime.day)}.${pad(session.startTime.month)}.${session.startTime.year}';
                  String timeStr =
                      '${pad(session.startTime.hour)}:${pad(session.startTime.minute)}';
                  String durStr =
                      '${session.duration.inMinutes}m ${session.duration.inSeconds.remainder(60)}s';

                  return Card(
                    elevation: 0,
                    margin: const EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => SessionDetailsPage(
                            patientId: patient.id,
                            session: session,
                            isDoctor: true,
                          ),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Icon(
                                  Icons.cloud_done,
                                  color: Color(0xFF0F4C81),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        dateStr,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 16,
                                        ),
                                      ),
                                      Text(
                                        'Godzina: $timeStr • Czas: $durStr',
                                        style: const TextStyle(
                                          color: Colors.black54,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Icon(
                                  Icons.chevron_right,
                                  color: Colors.grey,
                                ),
                              ],
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: Divider(height: 1),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _SessionStat(
                                  icon: Icons.air,
                                  label: 'Średni RR',
                                  value: session.avgRr.toStringAsFixed(1),
                                  color: Colors.green,
                                ),
                                if (session.apneaMonitored)
                                  _SessionStat(
                                    icon: Icons.warning_amber_rounded,
                                    label: 'Incydenty',
                                    value: session.apneaEvents.length
                                        .toString(),
                                    color: session.apneaEvents.isNotEmpty
                                        ? Colors.red
                                        : Colors.grey,
                                  )
                                else
                                  const _SessionStat(
                                    icon: Icons.health_and_safety,
                                    label: 'Bezdech',
                                    value: 'Wył.',
                                    color: Colors.grey,
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label, val;
  const _Stat({required this.label, required this.val});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(color: Colors.black54, fontSize: 12),
        ),
        const SizedBox(height: 4),
        Text(
          val,
          style: const TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 16,
            color: Color(0xFF0F4C81),
          ),
        ),
      ],
    );
  }
}

class _SessionStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _SessionStat({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 18,
            color: color,
          ),
        ),
        Text(
          label,
          style: const TextStyle(fontSize: 11, color: Colors.black54),
        ),
      ],
    );
  }
}

// ==========================================
// KONTO PACJENTA (POMIARY BLE I ZAPIS)
// ==========================================

class PatientMonitorPage extends StatefulWidget {
  final PatientProfile patient;
  final bool isCloudAccount;
  const PatientMonitorPage({
    super.key,
    required this.patient,
    this.isCloudAccount = false,
  });
  @override
  State<PatientMonitorPage> createState() => _PatientMonitorPageState();
}

class _PatientMonitorPageState extends State<PatientMonitorPage> {
  final BreathController _controller = BreathController();
  bool _isDevModeUnlocked = false;
  AppSection _selectedSection = AppSection.dashboard;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openAccountPage() async {
    if (_controller.isSessionActive) {
      await _controller.stopSession(
        cloudPatientId: widget.isCloudAccount ? widget.patient.id : null,
      );
    }
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => widget.isCloudAccount
            ? PatientMonitorPage(patient: PatientProfile.offline())
            : const LoginPage(),
      ),
    );
  }

  void _showPinDialog() {
    String enteredPin = '';
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text(
          'Tryb Dewelopera',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        content: TextField(
          autofocus: true,
          keyboardType: TextInputType.number,
          obscureText: true,
          decoration: InputDecoration(
            labelText: 'Wprowadź kod PIN',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
          onChanged: (val) => enteredPin = val,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Anuluj', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0F4C81),
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              if (enteredPin == '0000') {
                setState(() => _isDevModeUnlocked = true);
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Odblokowano tryb dewelopera')),
                );
              } else {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(const SnackBar(content: Text('Błędny kod PIN')));
              }
            },
            child: const Text('Odblokuj'),
          ),
        ],
      ),
    );
  }

  String _titleForSection() {
    switch (_selectedSection) {
      case AppSection.dashboard:
        return 'NOSE';
      case AppSection.apnea:
        return 'Monitor bezdechu';
      case AppSection.history:
        return 'Historia badań';
      case AppSection.charts:
        return 'Przebiegi sygnałów';
      case AppSection.rawData:
        return 'Diagnostyka';
    }
  }

  List<AppSection> get _activeSections {
    if (_isDevModeUnlocked) {
      return [
        AppSection.dashboard,
        AppSection.apnea,
        AppSection.history,
        AppSection.charts,
        AppSection.rawData,
      ];
    }
    return [AppSection.dashboard, AppSection.apnea, AppSection.history];
  }

  List<NavigationDestination> get _destinations {
    var dests = [
      const NavigationDestination(
        icon: Icon(Icons.monitor_heart_outlined),
        selectedIcon: Icon(Icons.monitor_heart),
        label: 'Główne',
      ),
      const NavigationDestination(
        icon: Icon(Icons.warning_amber_outlined),
        selectedIcon: Icon(Icons.warning_amber_rounded),
        label: 'Bezdech',
      ),
      const NavigationDestination(
        icon: Icon(Icons.history_outlined),
        selectedIcon: Icon(Icons.history),
        label: 'Historia',
      ),
    ];
    if (_isDevModeUnlocked) {
      dests.addAll([
        const NavigationDestination(
          icon: Icon(Icons.show_chart),
          selectedIcon: Icon(Icons.stacked_line_chart),
          label: 'Wykresy',
        ),
        const NavigationDestination(
          icon: Icon(Icons.developer_board_outlined),
          selectedIcon: Icon(Icons.developer_board),
          label: 'Diagnostyka',
        ),
      ]);
    }
    return dests;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titleForSection()),
        leading: Builder(
          builder: (context) => IconButton(
            tooltip: 'Konto i zapis danych',
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            tooltip: _isDevModeUnlocked
                ? 'Wyłącz tryb deweloperski'
                : 'Tryb deweloperski',
            icon: Icon(
              _isDevModeUnlocked ? Icons.lock_open : Icons.lock_outline,
              color: _isDevModeUnlocked ? Colors.redAccent : Colors.grey,
            ),
            onPressed: () {
              if (_isDevModeUnlocked) {
                setState(() {
                  _isDevModeUnlocked = false;
                  if (_selectedSection == AppSection.charts ||
                      _selectedSection == AppSection.rawData) {
                    _selectedSection = AppSection.dashboard;
                  }
                });
              } else {
                _showPinDialog();
              }
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary,
              ),
              accountName: Text(
                widget.patient.fullName,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                ),
              ),
              accountEmail: Text(
                widget.isCloudAccount
                    ? 'Zapis lokalny i synchronizacja online'
                    : 'Dane zapisywane na tym urządzeniu',
              ),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(
                  widget.isCloudAccount
                      ? Icons.cloud_done
                      : Icons.phone_android,
                  size: 34,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
            ListTile(
              leading: Icon(
                widget.isCloudAccount ? Icons.logout : Icons.cloud_outlined,
              ),
              title: Text(
                widget.isCloudAccount ? 'Wyloguj' : 'Konto online',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              onTap: _openAccountPage,
            ),
            if (!widget.isCloudAccount)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Text(
                  'Aplikacja działa bez internetu. Konto jest potrzebne tylko do synchronizacji.',
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ),
          ],
        ),
      ),
      body: Column(
        children: [
          _buildTopStatusBar(),
          Expanded(child: _buildContent()),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _activeSections.contains(_selectedSection)
            ? _activeSections.indexOf(_selectedSection)
            : 0,
        onDestinationSelected: (index) =>
            setState(() => _selectedSection = _activeSections[index]),
        destinations: _destinations,
      ),
    );
  }

  Widget _buildTopStatusBar() {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        bool isBelt = _controller.currentDeviceType != DeviceType.mask;
        final routeTxt = !_controller.isConnected
            ? 'Brak danych'
            : isBelt
            ? 'Sygnał z pasa'
            : (_controller.activeRoute == BreathingRoute.mouth
                  ? 'Ustami'
                  : 'Nosem');
        bool apneaAlert =
            _controller.isApneaMonitoringEnabled &&
            _controller.isApneaCurrentlyDetected;

        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: apneaAlert ? const Color(0xFFFFECEA) : Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: apneaAlert ? Colors.redAccent : const Color(0xFFDCE4E3),
            ),
          ),
          child: Row(
            children: [
              Icon(
                _controller.isConnected
                    ? Icons.bluetooth_connected
                    : Icons.bluetooth_disabled,
                color: _controller.isConnected
                    ? Theme.of(context).colorScheme.primary
                    : Colors.black45,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _controller.status,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(width: 12),
              Icon(isBelt ? Icons.monitor_heart_outlined : Icons.air, size: 20),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  routeTxt,
                  textAlign: TextAlign.end,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildContent() {
    switch (_selectedSection) {
      case AppSection.dashboard:
        return _buildDashboardPage();
      case AppSection.apnea:
        return _buildApneaPage();
      case AppSection.history:
        return _buildHistoryPage();
      case AppSection.charts:
        return _buildCombinedChartsPage();
      case AppSection.rawData:
        return _buildRawPage();
    }
  }

  // --- 1. Główne (Dashboard) ---
  Widget _buildDashboardPage() {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        final isBelt = _controller.currentDeviceType != DeviceType.mask;
        final routeLabel = isBelt
            ? getDeviceDisplayName(_controller.currentDeviceType)
            : _controller.activeRoute == BreathingRoute.mouth
            ? 'Usta'
            : 'Nos';
        final hasSignal =
            _controller.isConnected &&
            _controller.activeAnalyzer.rawSampleCount >=
                ChannelAnalyzer.slopeWindow;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFDCE4E3)),
              ),
              child: Column(
                children: [
                  DropdownButtonFormField<DeviceType>(
                    initialValue: _controller.currentDeviceType,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Urządzenie',
                      prefixIcon: Icon(Icons.sensors),
                    ),
                    onChanged:
                        (_controller.isConnected || _controller.isConnecting)
                        ? null
                        : (value) {
                            if (value != null) {
                              _controller.setDeviceType(value);
                            }
                          },
                    items: DeviceType.values
                        .map(
                          (type) => DropdownMenuItem(
                            value: type,
                            child: Text(
                              getDeviceDisplayName(type),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.tonalIcon(
                      onPressed: _controller.isConnecting
                          ? null
                          : () {
                              if (_controller.isConnected) {
                                _controller.disconnect();
                              } else {
                                _controller.connectFlow();
                              }
                            },
                      icon: Icon(
                        _controller.isConnected
                            ? Icons.bluetooth_disabled
                            : Icons.bluetooth_searching,
                      ),
                      label: Text(
                        _controller.isConnected
                            ? 'Rozłącz'
                            : _controller.isConnecting
                            ? 'Wyszukiwanie'
                            : 'Połącz',
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 56,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: _controller.isSessionActive
                      ? const Color(0xFFC43C35)
                      : Theme.of(context).colorScheme.primary,
                  foregroundColor: Colors.white,
                ),
                onPressed: () async {
                  if (!_controller.isConnected) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Najpierw połącz urządzenie.'),
                      ),
                    );
                    return;
                  }
                  if (_controller.isSessionActive) {
                    await _controller.stopSession(
                      cloudPatientId: widget.isCloudAccount
                          ? widget.patient.id
                          : null,
                    );
                    if (!context.mounted) return;
                    final message = _controller.lastSaveWasSynced
                        ? 'Badanie zapisano na urządzeniu i zsynchronizowano.'
                        : 'Badanie zapisano na urządzeniu.';
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(SnackBar(content: Text(message)));
                  } else {
                    _controller.startSession();
                  }
                },
                icon: Icon(
                  _controller.isSessionActive
                      ? Icons.stop
                      : Icons.fiber_manual_record,
                ),
                label: Text(
                  _controller.isSessionActive
                      ? 'Zakończ badanie'
                      : 'Rozpocznij badanie',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            if (_controller.isSessionActive)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.circle, color: Color(0xFFC43C35), size: 9),
                    SizedBox(width: 7),
                    Text(
                      'Rejestracja trwa',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 12),
            _RrCard(
              rr: _controller.currentRr,
              windowSeconds: _controller.rrWindowSeconds,
              routeTxt: routeLabel,
              showDetails: _isDevModeUnlocked,
            ),
            const SizedBox(height: 12),
            _MetronomeCard(controller: _controller),
            const SizedBox(height: 12),
            _MainBreathRectangle(
              state: _controller.mainState,
              hasSignal: hasSignal,
              routeText: isBelt
                  ? 'Ruch klatki piersiowej i brzucha'
                  : _controller.activeRoute == BreathingRoute.mouth
                  ? 'Oddychanie ustami'
                  : 'Oddychanie nosem',
            ),
            if (_isDevModeUnlocked) ...[
              const SizedBox(height: 12),
              _RrWindowSelector(
                selectedMode: _controller.rrWindowMode,
                onChanged: _controller.setRrWindowMode,
              ),
              const SizedBox(height: 12),
              _DeveloperDiagnostics(controller: _controller),
            ],
          ],
        );
      },
    );
  }

  // --- 2. Bezdech ---
  Widget _buildApneaPage() {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        final alert = _controller.isApneaCurrentlyDetected;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFDCE4E3)),
              ),
              child: SwitchListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 4,
                ),
                title: const Text(
                  'Monitor bezdechu',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: const Text('Przerwa oddechowa powyżej 10 s'),
                value: _controller.isApneaMonitoringEnabled,
                activeThumbColor: Theme.of(context).colorScheme.primary,
                onChanged: _controller.toggleApneaMonitoring,
                secondary: Icon(
                  Icons.health_and_safety_outlined,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
            if (_controller.isApneaMonitoringEnabled) ...[
              const SizedBox(height: 12),
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: alert ? const Color(0xFFC43C35) : Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: alert
                        ? const Color(0xFFC43C35)
                        : const Color(0xFFDCE4E3),
                  ),
                ),
                child: Column(
                  children: [
                    Icon(
                      alert
                          ? Icons.warning_rounded
                          : Icons.check_circle_outline,
                      color: alert ? Colors.white : const Color(0xFF168260),
                      size: 52,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      alert
                          ? 'Wykryto przerwę oddechową'
                          : 'Nie wykryto przerwy oddechowej',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: alert ? Colors.white : Colors.black87,
                      ),
                    ),
                    if (alert) ...[
                      const SizedBox(height: 8),
                      Text(
                        '${_controller.currentApneaDuration} s',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
            if (_controller.isApneaMonitoringEnabled ||
                _controller.apneaEventsCount > 0) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFFDCE4E3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.query_stats, color: Color(0xFFC43C35)),
                    const SizedBox(width: 14),
                    const Expanded(child: Text('Zarejestrowane incydenty')),
                    Text(
                      '${_controller.apneaEventsCount}',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  // --- 3. Historia Badań ---
  Widget _buildHistoryPage() {
    if (!widget.isCloudAccount) {
      return ValueListenableBuilder<List<SessionRecord>>(
        valueListenable: LocalSessionStore.records,
        builder: (context, sessions, _) =>
            _buildSessionList(sessions, isLocal: true),
      );
    }

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('patients')
          .doc(widget.patient.id)
          .collection('sessions')
          .orderBy('startTime', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(
            child: Text('Błąd pobierania danych: ${snapshot.error}'),
          );
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final sessions = snapshot.data!.docs
            .map(
              (doc) => SessionRecord.fromMap(
                doc.id,
                doc.data() as Map<String, dynamic>,
              ),
            )
            .toList();
        return _buildSessionList(sessions, isLocal: false);
      },
    );
  }

  Widget _buildSessionList(
    List<SessionRecord> sessions, {
    required bool isLocal,
  }) {
    if (sessions.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.history, size: 56, color: Colors.black26),
            SizedBox(height: 12),
            Text(
              'Brak zapisanych badań',
              style: TextStyle(
                color: Colors.black54,
                fontSize: 17,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      itemCount: sessions.length,
      itemBuilder: (context, index) {
        final session = sessions[index];
        String pad(int value) => value.toString().padLeft(2, '0');
        final date =
            '${pad(session.startTime.day)}.${pad(session.startTime.month)}.${session.startTime.year}';
        final time =
            '${pad(session.startTime.hour)}:${pad(session.startTime.minute)}';
        final duration =
            '${session.duration.inMinutes} min ${session.duration.inSeconds.remainder(60)} s';

        return Card(
          elevation: 0,
          margin: const EdgeInsets.only(bottom: 10),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: const BorderSide(color: Color(0xFFDCE4E3)),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SessionDetailsPage(
                  patientId: widget.patient.id,
                  session: session,
                  isDoctor: false,
                  isLocal: isLocal,
                ),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    isLocal ? Icons.phone_android : Icons.cloud_done,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '$date, $time',
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$duration  •  RR ${session.avgRr.toStringAsFixed(1)} oddechów/min',
                          style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: Colors.black38),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // --- 4. Wykresy Deweloperskie ---
  Widget _buildCombinedChartsPage() {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        if (_controller.currentDeviceType == DeviceType.mask) {
          return DefaultTabController(
            length: 2,
            child: Column(
              children: [
                const TabBar(
                  labelColor: Color(0xFF0F4C81),
                  unselectedLabelColor: Colors.grey,
                  indicatorColor: Color(0xFF0F4C81),
                  tabs: [
                    Tab(icon: Icon(Icons.thermostat), text: 'Temperatura'),
                    Tab(icon: Icon(Icons.water_drop), text: 'Wilgotność'),
                  ],
                ),
                Expanded(
                  child: TabBarView(
                    children: [_buildMaskCharts(true), _buildMaskCharts(false)],
                  ),
                ),
              ],
            ),
          );
        } else {
          return Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: Text(
                  "Przebieg z Pasa (Surowy sygnał odfiltrowany)",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0F4C81),
                  ),
                ),
              ),
              Expanded(
                child: _buildChartWithIndicator(
                  title: 'Sygnał klatki piersiowej i brzucha',
                  spots: _controller.belt.spots,
                  analyzer: _controller.belt,
                  color: Colors.blueAccent,
                  unit: '',
                  isBelt: true,
                ),
              ),
            ],
          );
        }
      },
    );
  }

  Widget _buildMaskCharts(bool isTemp) {
    return ListView(
      padding: const EdgeInsets.only(bottom: 20, top: 12),
      children: [
        _buildChartWithIndicator(
          title: 'Usta',
          spots: isTemp
              ? _controller.mouth.spots
              : _controller.mouth.humiditySpots,
          analyzer: _controller.mouth,
          color: Colors.red,
          unit: isTemp ? '°' : '%',
          isBelt: false,
        ),
        _buildChartWithIndicator(
          title: 'Prawe nozdrze',
          spots: isTemp
              ? _controller.right.spots
              : _controller.right.humiditySpots,
          analyzer: _controller.right,
          color: Colors.green,
          unit: isTemp ? '°' : '%',
          isBelt: false,
        ),
        _buildChartWithIndicator(
          title: 'Lewe nozdrze',
          spots: isTemp
              ? _controller.left.spots
              : _controller.left.humiditySpots,
          analyzer: _controller.left,
          color: Colors.blue,
          unit: isTemp ? '°' : '%',
          isBelt: false,
        ),
      ],
    );
  }

  // --- 5. Surowe Dane ---
  Widget _buildRawPage() {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        if (_controller.currentDeviceType != DeviceType.mask) {
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const Text(
                        "SUROWY ODCZYT Z PASA",
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        _controller.belt.rawSpots.isNotEmpty
                            ? _controller.belt.rawSpots.last.y.toStringAsFixed(
                                2,
                              )
                            : '--',
                        style: const TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0F4C81),
                        ),
                      ),
                      const SizedBox(height: 20),
                      _BreathIndicator(state: _controller.mainState),
                    ],
                  ),
                ),
              ),
            ],
          );
        }

        final s = _controller.latestSample;
        String v(double? val, String unit) =>
            val == null ? '--' : '${val.toStringAsFixed(2)} $unit';

        return ListView(
          padding: const EdgeInsets.only(bottom: 20),
          children: [
            Row(
              children: [
                const SizedBox(width: 16),
                Expanded(
                  child: _SensorSummaryCard(
                    title: 'Usta',
                    color: Colors.red,
                    tempText: v(s?.tempMouth, '°C'),
                    humText: v(s?.humMouth, '%'),
                    state: _controller.mouth.currentState,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _SensorSummaryCard(
                    title: 'P. Nozdrze',
                    color: Colors.green,
                    tempText: v(s?.tempRight, '°C'),
                    humText: v(s?.humRight, '%'),
                    state: _controller.right.currentState,
                  ),
                ),
                const SizedBox(width: 16),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const SizedBox(width: 16),
                Expanded(
                  child: _SensorSummaryCard(
                    title: 'L. Nozdrze',
                    color: Colors.blue,
                    tempText: v(s?.tempLeft, '°C'),
                    humText: v(s?.humLeft, '%'),
                    state: _controller.left.currentState,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _CompactAmbientCard(
                    tempText: v(s?.tAmb, '°C'),
                    humText: v(s?.hAmb, '%'),
                  ),
                ),
                const SizedBox(width: 16),
              ],
            ),
            Container(
              margin: const EdgeInsets.all(16),
              child: Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Text(
                        'Wartości z ramki BLE',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 14),
                      _RawRow(
                        label: 'Usta (t0, h0)',
                        temp: v(s?.t0, '°C'),
                        hum: v(s?.h0, '%'),
                        color: Colors.red,
                      ),
                      _RawRow(
                        label: 'Prawe no. (t1, h1)',
                        temp: v(s?.t1, '°C'),
                        hum: v(s?.h1, '%'),
                        color: Colors.green,
                      ),
                      _RawRow(
                        label: 'Lewe no. (t2, h2)',
                        temp: v(s?.t2, '°C'),
                        hum: v(s?.h2, '%'),
                        color: Colors.blue,
                      ),
                      _RawRow(
                        label: 'Otoczenie (tAmb)',
                        temp: v(s?.tAmb, '°C'),
                        hum: v(s?.hAmb, '%'),
                        color: Colors.grey,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildChartWithIndicator({
    required String title,
    required List<FlSpot> spots,
    required ChannelAnalyzer analyzer,
    required Color color,
    required String unit,
    required bool isBelt,
  }) {
    double maxX = spots.isEmpty ? 10.0 : spots.last.x;
    double minX = math.max(0, maxX - ChannelAnalyzer.chartWindowSeconds);

    double actualMin = spots.isEmpty ? 0 : spots.first.y;
    double actualMax = spots.isEmpty ? 0 : spots.first.y;
    for (var spot in spots) {
      if (spot.y < actualMin) actualMin = spot.y;
      if (spot.y > actualMax) actualMax = spot.y;
    }

    double range = actualMax - actualMin;
    double minR = 2.0;
    if (isBelt) {
      if (_controller.currentDeviceType == DeviceType.tensometricBelt) {
        minR = 500.0;
      } else if (_controller.currentDeviceType == DeviceType.barometricBelt) {
        minR = 0.5;
      }
    }

    if (range < minR) {
      double center = (actualMax + actualMin) / 2;
      actualMin = center - minR / 2;
      actualMax = center + minR / 2;
      range = minR;
    }
    double padding = range * 0.15;
    double finalMinY = actualMin - padding;
    double finalMaxY = actualMax + padding;

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              SizedBox(
                height: isBelt ? 300 : 200,
                child: Row(
                  children: [
                    Expanded(
                      child: LineChart(
                        LineChartData(
                          minX: minX,
                          maxX: maxX < 10 ? 10 : maxX,
                          minY: finalMinY,
                          maxY: finalMaxY,
                          rangeAnnotations: RangeAnnotations(
                            verticalRangeAnnotations: analyzer.segments
                                .map(
                                  (seg) => VerticalRangeAnnotation(
                                    x1: math.max(seg.startX, minX),
                                    x2: seg.endX,
                                    color: seg.state == BreathState.inhale
                                        ? Colors.green.withValues(alpha: 0.15)
                                        : Colors.red.withValues(alpha: 0.15),
                                  ),
                                )
                                .toList(),
                          ),
                          gridData: const FlGridData(
                            show: true,
                            drawVerticalLine: false,
                          ),
                          borderData: FlBorderData(
                            show: true,
                            border: Border.all(color: const Color(0xFFE8ECF3)),
                          ),
                          titlesData: FlTitlesData(
                            topTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            rightTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            bottomTitles: const AxisTitles(
                              sideTitles: SideTitles(showTitles: false),
                            ),
                            leftTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                reservedSize: 40,
                                getTitlesWidget: (v, m) => Text(
                                  v.toInt().toString() + unit,
                                  style: const TextStyle(fontSize: 10),
                                ),
                              ),
                            ),
                          ),
                          lineBarsData: [
                            LineChartBarData(
                              spots: spots,
                              isCurved: isBelt,
                              color: color,
                              barWidth: 3,
                              dotData: const FlDotData(show: false),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    _BreathIndicator(state: analyzer.currentState),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- WIDGETY POMOCNICZE (Odświeżone z 1.txt) ---

class _RrWindowSelector extends StatelessWidget {
  final RrWindowMode selectedMode;
  final ValueChanged<RrWindowMode> onChanged;
  const _RrWindowSelector({
    required this.selectedMode,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: const BorderSide(color: Color(0xFFDCE4E3)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Okno estymacji RR',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Ustawienie deweloperskie',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ],
              ),
            ),
            SegmentedButton<RrWindowMode>(
              showSelectedIcon: false,
              segments: RrWindowMode.values
                  .map(
                    (mode) => ButtonSegment<RrWindowMode>(
                      value: mode,
                      label: Text(mode.label),
                    ),
                  )
                  .toList(),
              selected: {selectedMode},
              onSelectionChanged: (selection) {
                if (selection.isNotEmpty) onChanged(selection.first);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _RrCard extends StatelessWidget {
  final double rr;
  final int windowSeconds;
  final String routeTxt;
  final bool showDetails;
  const _RrCard({
    required this.rr,
    required this.windowSeconds,
    required this.routeTxt,
    required this.showDetails,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFDCE4E3)),
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.air,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  size: 30,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Częstość oddechu',
                      style: TextStyle(color: Colors.black54, fontSize: 13),
                    ),
                    const SizedBox(height: 2),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            rr > 0 ? rr.toStringAsFixed(1) : '--',
                            style: TextStyle(
                              color: Theme.of(context).colorScheme.primary,
                              fontSize: 40,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.only(left: 7, bottom: 6),
                            child: Text(
                              'oddechów/min',
                              style: TextStyle(
                                color: Colors.black54,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (showDetails) ...[
            const Divider(height: 28),
            Row(
              children: [
                Expanded(
                  child: _InlineMetric(label: 'Źródło', value: routeTxt),
                ),
                const SizedBox(width: 12),
                _InlineMetric(label: 'Okno RR', value: '$windowSeconds s'),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _MetronomeCard extends StatelessWidget {
  final BreathController controller;
  const _MetronomeCard({required this.controller});

  @override
  Widget build(BuildContext context) {
    final active = controller.metronomeRate > 0;
    final inhale = controller.metronomeState == BreathState.inhale;
    final measured = controller.currentRr;
    final error = controller.metronomeError;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFDCE4E3)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                Icons.timer_outlined,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Metronom testowy',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              DropdownButtonHideUnderline(
                child: DropdownButton<int>(
                  value: controller.metronomeRate,
                  items: const [
                    DropdownMenuItem(value: 0, child: Text('Wył.')),
                    DropdownMenuItem(value: 6, child: Text('6/min')),
                    DropdownMenuItem(value: 12, child: Text('12/min')),
                    DropdownMenuItem(value: 20, child: Text('20/min')),
                  ],
                  onChanged: (value) {
                    if (value != null) controller.setMetronomeRate(value);
                  },
                ),
              ),
            ],
          ),
          if (active) ...[
            const Divider(height: 24),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: inhale
                    ? const Color(0xFFE2F3EC)
                    : const Color(0xFFFFE9E7),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                inhale ? 'WDECH' : 'WYDECH',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: inhale
                      ? const Color(0xFF12684E)
                      : const Color(0xFFA9322D),
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _MetronomeMetric(
                    label: 'Zadane',
                    value: '${controller.metronomeRate}',
                  ),
                ),
                Expanded(
                  child: _MetronomeMetric(
                    label: 'Zmierzone',
                    value: measured > 0 ? measured.toStringAsFixed(1) : '--',
                  ),
                ),
                Expanded(
                  child: _MetronomeMetric(
                    label: 'Błąd',
                    value: error == null
                        ? '--'
                        : '${error >= 0 ? '+' : ''}${error.toStringAsFixed(1)}',
                  ),
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.only(top: 5),
              child: Text(
                'oddechów/min',
                style: TextStyle(color: Colors.black45, fontSize: 11),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _MetronomeMetric extends StatelessWidget {
  final String label;
  final String value;
  const _MetronomeMetric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(color: Colors.black54, fontSize: 11),
        ),
        const SizedBox(height: 2),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            value,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
        ),
      ],
    );
  }
}

class _InlineMetric extends StatelessWidget {
  final String label;
  final String value;
  const _InlineMetric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(color: Colors.black45, fontSize: 11),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
        ),
      ],
    );
  }
}

class _DeveloperDiagnostics extends StatelessWidget {
  final BreathController controller;
  const _DeveloperDiagnostics({required this.controller});

  @override
  Widget build(BuildContext context) {
    final isTemperature = controller.currentDeviceType == DeviceType.mask;
    final quality = controller.activeAnalyzer.signalQuality(20);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFDCE4E3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.tune, size: 20),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Diagnostyka algorytmu',
                  maxLines: 2,
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          _DiagnosticRow(
            label: 'Filtracja',
            value: controller.activeFilterName,
          ),
          _DiagnosticRow(
            label: 'Estymator RR',
            value: controller.activeEstimatorName,
          ),
          _DiagnosticRow(
            label: 'Detekcja fazy',
            value: controller.activeAnalyzer.phaseMethodName,
          ),
          _DiagnosticRow(
            label: 'Jakość aktywnego kanału',
            value: quality.toStringAsFixed(2),
          ),
          if (!isTemperature)
            _DiagnosticRow(
              label: 'Nachylenie / próg',
              value:
                  '${controller.belt.currentSlope.toStringAsFixed(3)} / ${controller.belt.phaseThreshold.toStringAsFixed(3)}',
            ),
          _DiagnosticRow(
            label: 'Próbki w buforze',
            value: '${controller.activeAnalyzer.rawSampleCount}',
          ),
          if (isTemperature) ...[
            _DiagnosticRow(
              label: 'Aktywne nozdrze',
              value: controller.activeNostril,
            ),
            _DiagnosticRow(
              label: 'Cykle w oknie 20 s',
              value:
                  'usta ${controller.routeMouthCycles}, nos ${controller.routeNoseCycles}',
            ),
            _DiagnosticRow(
              label: 'Pewność toru',
              value: '${(controller.routeConfidence * 100).round()}%',
            ),
          ],
        ],
      ),
    );
  }
}

class _DiagnosticRow extends StatelessWidget {
  final String label;
  final String value;
  const _DiagnosticRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(color: Colors.black54, fontSize: 12),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}

class _SensorSummaryCard extends StatelessWidget {
  final String title, tempText, humText;
  final Color color;
  final BreathState state;
  const _SensorSummaryCard({
    required this.title,
    required this.color,
    required this.tempText,
    required this.humText,
    required this.state,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'Temp',
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
            Text(
              tempText,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const Text(
              'Wilg',
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
            Text(
              humText,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

class _CompactAmbientCard extends StatelessWidget {
  final String tempText, humText;
  const _CompactAmbientCard({required this.tempText, required this.humText});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.public, size: 16, color: Colors.grey),
                SizedBox(width: 8),
                Text(
                  'Otoczenie',
                  style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'Temp',
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
            Text(
              tempText,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            const Text(
              'Wilg',
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
            Text(
              humText,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}

class _RawRow extends StatelessWidget {
  final String label, temp, hum;
  final Color color;
  const _RawRow({
    required this.label,
    required this.temp,
    required this.hum,
    required this.color,
  });
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(temp, style: const TextStyle(fontSize: 14)),
          ),
          Expanded(
            flex: 3,
            child: Text(hum, style: const TextStyle(fontSize: 14)),
          ),
        ],
      ),
    );
  }
}

class _BreathIndicator extends StatelessWidget {
  final BreathState state;
  const _BreathIndicator({required this.state});
  @override
  Widget build(BuildContext context) {
    bool isInhale = state == BreathState.inhale;
    return Container(
      width: 70,
      height: double.infinity,
      decoration: BoxDecoration(
        color: isInhale ? const Color(0xFF168260) : const Color(0xFFC43C35),
        borderRadius: BorderRadius.circular(8),
      ),
      alignment: Alignment.center,
      child: RotatedBox(
        quarterTurns: 3,
        child: Text(
          isInhale ? 'WDECH' : 'WYDECH',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            fontSize: 16,
          ),
        ),
      ),
    );
  }
}

class _MainBreathRectangle extends StatelessWidget {
  final BreathState state;
  final String routeText;
  final bool hasSignal;
  const _MainBreathRectangle({
    required this.state,
    required this.routeText,
    required this.hasSignal,
  });
  @override
  Widget build(BuildContext context) {
    bool isInhale = state == BreathState.inhale;
    final backgroundColor = !hasSignal
        ? const Color(0xFF677574)
        : isInhale
        ? const Color(0xFF168260)
        : const Color(0xFFC43C35);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      width: double.infinity,
      height: 220,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            !hasSignal
                ? Icons.sensors_off_outlined
                : isInhale
                ? Icons.arrow_downward
                : Icons.arrow_upward,
            color: Colors.white,
            size: 48,
          ),
          const SizedBox(height: 12),
          Text(
            !hasSignal
                ? 'OCZEKIWANIE'
                : isInhale
                ? 'WDECH'
                : 'WYDECH',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 32,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              hasSignal ? routeText : 'Oczekiwanie na sygnał z urządzenia',
              textAlign: TextAlign.center,
              maxLines: 2,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
