# NOSE - aplikacja monitorująca

Aplikacja Flutter prezentuje sygnały przesyłane przez urządzenia BLE i
wyznacza bieżącą częstość oddechu `RR [oddechy/min]` w prawostronnym oknie
10 lub 20 sekund. Kod ma charakter prototypu badawczego i nie jest wyrobem
medycznym.

## Konfiguracja Firebase

Repozytorium celowo nie zawiera danych rzeczywistego projektu Firebase.
Wartości należy przekazać podczas uruchamiania:

```text
flutter run \
  --dart-define=FIREBASE_API_KEY=... \
  --dart-define=FIREBASE_APP_ID=... \
  --dart-define=FIREBASE_SENDER_ID=... \
  --dart-define=FIREBASE_PROJECT_ID=... \
  --dart-define=FIREBASE_DATABASE_URL=... \
  --dart-define=FIREBASE_STORAGE_BUCKET=... \
  --dart-define=NOSE_CLINICIAN_LOGIN=... \
  --dart-define=NOSE_CLINICIAN_PASSWORD=...
```

Plik `google-services.json`, klucze podpisu oraz lokalne pliki środowiskowe
nie powinny trafiać do repozytorium.

Gotowy plik APK zamieszczony w `releases/` jest wariantem lokalnym. Pozwala
połączyć urządzenie BLE, prowadzić pomiar, prezentować fazę i częstość oddechu,
uruchomić metronom oraz zapisywać sesje bez logowania. Synchronizacja Firebase
pozostaje nieaktywna do czasu podania prywatnej konfiguracji podczas kompilacji.

## Budowanie

```text
flutter pub get
flutter analyze
flutter build apk --release
```

## Ograniczenia

- Metoda bieżąca jest metodą heurystyczną opartą na zmianie fazy sygnału.
- Komunikat o braku wykrytego cyklu oznacza błąd lub przerwę detekcji, a nie
  rozpoznanie bezdechu.
- Logowanie pacjenta przez porównanie hasła w bazie jest wyłącznie demonstracją.
  W zastosowaniu produkcyjnym należy użyć Firebase Authentication, skrótów haseł,
  reguł Firestore i kontroli ról.

Szczegóły bezpieczeństwa opisano w głównym pliku `SECURITY.md` repozytorium.
