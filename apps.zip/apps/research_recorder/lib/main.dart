import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';

const String appVersion = '1.0.0+1';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ResearchApp());
}

enum DeviceType { glasses, tensometricBelt, pressureBelt }

enum ParserType { glassesCsv8, rawHx711, rawPressure }

enum ProtocolMode {
  technicalTest,
  walkingMetronomeTest,
  variableMetronomeOnlineTest,
  walkRunTest,
  shortSession,
  fullSession,
}

extension ProtocolModeLabels on ProtocolMode {
  String get label {
    switch (this) {
      case ProtocolMode.technicalTest:
        return 'Test techniczny';
      case ProtocolMode.walkingMetronomeTest:
        return 'Chód + metronom';
      case ProtocolMode.variableMetronomeOnlineTest:
        return 'Zmienny metronom: siedzenie + chód';
      case ProtocolMode.walkRunTest:
        return 'Przygotowanie + chód + bieg';
      case ProtocolMode.shortSession:
        return 'Sesja skrócona';
      case ProtocolMode.fullSession:
        return 'Sesja pełna';
    }
  }

  String get fileValue {
    switch (this) {
      case ProtocolMode.technicalTest:
        return 'technical_test';
      case ProtocolMode.walkingMetronomeTest:
        return 'walking_metronome_test';
      case ProtocolMode.variableMetronomeOnlineTest:
        return 'variable_metronome_sit_walk_test';
      case ProtocolMode.walkRunTest:
        return 'walk_run_test';
      case ProtocolMode.shortSession:
        return 'short_session';
      case ProtocolMode.fullSession:
        return 'full_session';
    }
  }
}

class DeviceConfig {
  final DeviceType deviceType;
  final String displayName;
  final String bleName;
  final String serviceUuid;
  final String characteristicUuid;
  final double nominalSamplingHz;
  final ParserType parserType;
  final String csvFileName;

  const DeviceConfig({
    required this.deviceType,
    required this.displayName,
    required this.bleName,
    required this.serviceUuid,
    required this.characteristicUuid,
    required this.nominalSamplingHz,
    required this.parserType,
    required this.csvFileName,
  });

  Map<String, Object> toJson() {
    return {
      'device_type': deviceType.name,
      'display_name': displayName,
      'ble_name': bleName,
      'service_uuid': serviceUuid,
      'characteristic_uuid': characteristicUuid,
      'nominal_sampling_hz': nominalSamplingHz,
      'parser_type': parserType.name,
      'csv_file_name': csvFileName,
    };
  }
}

const List<DeviceConfig> deviceConfigs = [
  DeviceConfig(
    deviceType: DeviceType.glasses,
    displayName: 'Okulary BME280',
    bleName: 'ESP32S3_BME280_4x',
    serviceUuid: '4fafc201-1fb5-459e-8fcc-c5c9c331914b',
    characteristicUuid: 'beb5483e-36e1-4688-b7f5-ea07361b26a8',
    nominalSamplingHz: 5,
    parserType: ParserType.glassesCsv8,
    csvFileName: 'raw_glasses.csv',
  ),
  DeviceConfig(
    deviceType: DeviceType.tensometricBelt,
    displayName: 'Pas tensometryczny',
    bleName: 'Pas_Tensometryczny',
    serviceUuid: '4fafc201-1fb5-459e-8fcc-c5c9c331914b',
    characteristicUuid: 'beb5483e-36e1-4688-b7f5-ea07361b26a8',
    nominalSamplingHz: 10,
    parserType: ParserType.rawHx711,
    csvFileName: 'raw_tensometric_belt.csv',
  ),
  DeviceConfig(
    deviceType: DeviceType.pressureBelt,
    displayName: 'Pas barometryczny',
    bleName: 'Pas_Barometryczny',
    serviceUuid: '4fafc201-1fb5-459e-8fcc-c5c9c331914b',
    characteristicUuid: 'beb5483e-36e1-4688-b7f5-ea07361b26a8',
    nominalSamplingHz: 10,
    parserType: ParserType.rawPressure,
    csvFileName: 'raw_pressure_belt.csv',
  ),
];

DeviceConfig configFor(DeviceType type) {
  return deviceConfigs.firstWhere((config) => config.deviceType == type);
}

class ParsedFrame {
  final String rawPayload;
  final bool parseOk;
  final Map<String, String> values;
  final Map<String, double> plotValues;
  final int nanCount;

  const ParsedFrame({
    required this.rawPayload,
    required this.parseOk,
    required this.values,
    required this.plotValues,
    required this.nanCount,
  });
}

class QualityStats {
  int sampleCount = 0;
  int validFrameCount = 0;
  int badFrameCount = 0;
  int nanCount = 0;
  int disconnectCount = 0;
  int? firstSampleTimestampMs;
  int? lastSampleTimestampMs;
  int? minIntervalMs;
  int? maxIntervalMs;
  DateTime? lastSampleDateTime;

  void reset() {
    sampleCount = 0;
    validFrameCount = 0;
    badFrameCount = 0;
    nanCount = 0;
    disconnectCount = 0;
    firstSampleTimestampMs = null;
    lastSampleTimestampMs = null;
    minIntervalMs = null;
    maxIntervalMs = null;
    lastSampleDateTime = null;
  }

  void recordSample({
    required int timestampMs,
    required bool parseOk,
    required int frameNanCount,
  }) {
    sampleCount++;
    if (parseOk) {
      validFrameCount++;
    } else {
      badFrameCount++;
    }
    nanCount += frameNanCount;

    firstSampleTimestampMs ??= timestampMs;
    if (lastSampleTimestampMs != null) {
      final interval = timestampMs - lastSampleTimestampMs!;
      if (interval >= 0) {
        minIntervalMs = minIntervalMs == null
            ? interval
            : math.min(minIntervalMs!, interval);
        maxIntervalMs = maxIntervalMs == null
            ? interval
            : math.max(maxIntervalMs!, interval);
      }
    }
    lastSampleTimestampMs = timestampMs;
    lastSampleDateTime = DateTime.now();
  }

  void recordDisconnect() {
    disconnectCount++;
  }

  double get averageHz {
    if (sampleCount < 2 ||
        firstSampleTimestampMs == null ||
        lastSampleTimestampMs == null) {
      return 0;
    }
    final durationMs = lastSampleTimestampMs! - firstSampleTimestampMs!;
    if (durationMs <= 0) return 0;
    return (sampleCount - 1) * 1000 / durationMs;
  }

  double get validPercent {
    if (sampleCount == 0) return 0;
    return validFrameCount * 100 / sampleCount;
  }

  String lastSampleAgeLabel() {
    if (lastSampleDateTime == null) return '-';
    final ageMs = DateTime.now().difference(lastSampleDateTime!).inMilliseconds;
    if (ageMs < 1000) return '$ageMs ms';
    return '${(ageMs / 1000).toStringAsFixed(1)} s';
  }

  String statusFor(double nominalHz) {
    if (sampleCount == 0) return 'BAD';
    if (validPercent < 90) return 'BAD';
    if (averageHz > 0 && averageHz < nominalHz * 0.5) return 'WARNING';
    if (validPercent < 98 || disconnectCount > 0 || nanCount > 0) {
      return 'WARNING';
    }
    return 'OK';
  }

  Map<String, Object?> toJson(DeviceConfig config) {
    return {
      'device_type': config.deviceType.name,
      'device_name': config.displayName,
      'ble_name': config.bleName,
      'sample_count': sampleCount,
      'average_sampling_hz': double.parse(averageHz.toStringAsFixed(3)),
      'min_interval_ms': minIntervalMs,
      'max_interval_ms': maxIntervalMs,
      'bad_frame_count': badFrameCount,
      'nan_count': nanCount,
      'disconnect_count': disconnectCount,
      'valid_frame_percent': double.parse(validPercent.toStringAsFixed(2)),
      'status': statusFor(config.nominalSamplingHz),
    };
  }
}

class DeviceRuntimeState {
  final DeviceConfig config;
  BluetoothDevice? device;
  BluetoothCharacteristic? characteristic;
  StreamSubscription<List<int>>? notifySub;
  StreamSubscription<BluetoothConnectionState>? connectionSub;
  String status = 'Rozłączono';
  bool isConnecting = false;
  bool selected = true;
  int _nextSampleIndex = 0;
  int _plotIndex = 0;
  final QualityStats quality = QualityStats();
  final Map<String, List<FlSpot>> series = {};

  DeviceRuntimeState(this.config);

  bool get isConnected => device != null;

  int nextSampleIndex() {
    final current = _nextSampleIndex;
    _nextSampleIndex++;
    return current;
  }

  void resetForSession() {
    _nextSampleIndex = 0;
    quality.reset();
    series.clear();
    _plotIndex = 0;
  }

  void addPlotValues(Map<String, double> values) {
    if (values.isEmpty) return;
    _plotIndex++;
    for (final entry in values.entries) {
      final list = series.putIfAbsent(entry.key, () => <FlSpot>[]);
      list.add(FlSpot(_plotIndex.toDouble(), entry.value));
      if (list.length > 150) list.removeAt(0);
    }
  }
}

class ProtocolStep {
  final String label;
  final String eventType;
  final Duration duration;
  final int metronomeBpm;
  final String? eventNote;

  const ProtocolStep({
    required this.label,
    required this.eventType,
    required this.duration,
    this.metronomeBpm = 0,
    this.eventNote,
  });
}

class ProtocolController {
  final Future<void> Function(String eventType, String note) onEvent;
  final VoidCallback onChanged;
  final Future<void> Function() onFinished;

  Timer? _stepTimer;
  Timer? _metronomeTimer;
  List<ProtocolStep> steps = const [];
  int currentIndex = -1;
  int remainingSeconds = 0;
  bool isRunning = false;
  bool isMetronomeInhale = true;
  int currentMetronomeBpm = 0;

  ProtocolController({
    required this.onEvent,
    required this.onChanged,
    required this.onFinished,
  });

  ProtocolStep? get currentStep {
    if (currentIndex < 0 || currentIndex >= steps.length) return null;
    return steps[currentIndex];
  }

  String get currentStepLabel => currentStep?.label ?? 'Brak aktywnej sesji';

  String get nextStepLabel {
    final nextIndex = currentIndex + 1;
    if (nextIndex < 0 || nextIndex >= steps.length) return 'Koniec';
    return steps[nextIndex].label;
  }

  void start(ProtocolMode mode) {
    stop();
    steps = protocolStepsFor(mode);
    currentIndex = -1;
    isRunning = true;
    _startNextStep();
  }

  void stop() {
    _stepTimer?.cancel();
    _metronomeTimer?.cancel();
    _stepTimer = null;
    _metronomeTimer = null;
    isRunning = false;
    currentMetronomeBpm = 0;
    remainingSeconds = 0;
  }

  void dispose() {
    stop();
  }

  void _startNextStep() {
    _stepTimer?.cancel();
    _metronomeTimer?.cancel();
    currentIndex++;

    if (currentIndex >= steps.length) {
      isRunning = false;
      currentMetronomeBpm = 0;
      remainingSeconds = 0;
      onChanged();
      unawaited(onFinished());
      return;
    }

    final step = steps[currentIndex];
    remainingSeconds = step.duration.inSeconds;
    currentMetronomeBpm = step.metronomeBpm;
    isMetronomeInhale = true;
    unawaited(onEvent(step.eventType, step.eventNote ?? step.label));
    _startMetronome(step.metronomeBpm);

    _stepTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      remainingSeconds--;
      if (remainingSeconds <= 0) {
        _startNextStep();
      } else {
        onChanged();
      }
    });
    onChanged();
  }

  void _startMetronome(int bpm) {
    if (bpm <= 0) return;
    final halfCycleMs = (60000 / bpm / 2).round();
    _metronomeTimer = Timer.periodic(Duration(milliseconds: halfCycleMs), (_) {
      isMetronomeInhale = !isMetronomeInhale;
      onChanged();
    });
  }
}

const List<int> variableMetronomeBpmSequence = [
  10,
  15,
  20,
  25,
  10,
  15,
  20,
  25,
  10,
  15,
  20,
  25,
];

List<ProtocolStep> variableMetronomeSitWalkSteps() {
  final steps = <ProtocolStep>[];

  void addVariableMetronomePhase({
    required String phase,
    required String labelPrefix,
    required String eventPrefix,
  }) {
    for (var i = 0; i < variableMetronomeBpmSequence.length; i++) {
      final segment = i + 1;
      final bpm = variableMetronomeBpmSequence[i];
      steps.add(
        ProtocolStep(
          label: '$labelPrefix $bpm/min',
          eventType: '${eventPrefix}_${bpm}_START',
          duration: const Duration(seconds: 10),
          metronomeBpm: bpm,
          eventNote:
              'phase=$phase;segment=$segment;target_bpm=$bpm;duration_s=10;mode=variable_metronome',
        ),
      );
    }
  }

  addVariableMetronomePhase(
    phase: 'sitting',
    labelPrefix: 'Siedząc',
    eventPrefix: 'VARIABLE_SITTING_METRONOME',
  );

  steps.add(
    const ProtocolStep(
      label: 'Przerwa - przygotuj chód',
      eventType: 'VARIABLE_METRONOME_BREAK_START',
      duration: Duration(seconds: 10),
      eventNote:
          'phase=break;duration_s=10;target_bpm=0;mode=variable_metronome',
    ),
  );

  addVariableMetronomePhase(
    phase: 'walking',
    labelPrefix: 'Chodząc',
    eventPrefix: 'VARIABLE_WALKING_METRONOME',
  );

  return steps;
}

List<ProtocolStep> protocolStepsFor(ProtocolMode mode) {
  switch (mode) {
    case ProtocolMode.technicalTest:
      return const [
        ProtocolStep(
          label: 'Test techniczny',
          eventType: 'TECHNICAL_TEST_START',
          duration: Duration(seconds: 60),
        ),
      ];
    case ProtocolMode.walkingMetronomeTest:
      return const [
        ProtocolStep(
          label: 'Chód + metronom 12/min',
          eventType: 'WALK_METRONOME_12_START',
          duration: Duration(minutes: 2),
          metronomeBpm: 12,
        ),
        ProtocolStep(
          label: 'Chód + metronom 20/min',
          eventType: 'WALK_METRONOME_20_START',
          duration: Duration(minutes: 2),
          metronomeBpm: 20,
        ),
      ];
    case ProtocolMode.variableMetronomeOnlineTest:
      return variableMetronomeSitWalkSteps();
    case ProtocolMode.walkRunTest:
      return const [
        ProtocolStep(
          label: 'Przygotowanie do chodu',
          eventType: 'WALK_RUN_PREPARATION_START',
          duration: Duration(seconds: 10),
          eventNote: 'phase=preparation;duration_s=10;mode=walk_run_test',
        ),
        ProtocolStep(
          label: 'Chód + metronom 20/min',
          eventType: 'WALK_RUN_WALKING_START',
          duration: Duration(minutes: 1),
          metronomeBpm: 20,
          eventNote:
              'phase=walking;duration_s=60;target_bpm=20;mode=walk_run_test',
        ),
        ProtocolStep(
          label: 'Bieg + metronom 20/min',
          eventType: 'WALK_RUN_RUNNING_START',
          duration: Duration(minutes: 1),
          metronomeBpm: 20,
          eventNote:
              'phase=running;duration_s=60;target_bpm=20;mode=walk_run_test',
        ),
      ];
    case ProtocolMode.shortSession:
      return const [
        ProtocolStep(
          label: 'Spoczynek',
          eventType: 'REST_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Metronom 12/min',
          eventType: 'METRONOME_12_START',
          duration: Duration(seconds: 60),
          metronomeBpm: 12,
        ),
        ProtocolStep(
          label: 'Mowa',
          eventType: 'SPEECH_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Ruch / chód',
          eventType: 'WALK_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Kaszel',
          eventType: 'COUGH_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Spoczynek końcowy',
          eventType: 'FINAL_REST_START',
          duration: Duration(seconds: 60),
        ),
      ];
    case ProtocolMode.fullSession:
      return const [
        ProtocolStep(
          label: 'Stabilizacja',
          eventType: 'STABILIZATION_START',
          duration: Duration(seconds: 10),
        ),
        ProtocolStep(
          label: 'Spoczynek',
          eventType: 'REST_START',
          duration: Duration(seconds: 120),
        ),
        ProtocolStep(
          label: 'Metronom 6/min',
          eventType: 'METRONOME_6_START',
          duration: Duration(seconds: 90),
          metronomeBpm: 6,
        ),
        ProtocolStep(
          label: 'Metronom 12/min',
          eventType: 'METRONOME_12_START',
          duration: Duration(seconds: 90),
          metronomeBpm: 12,
        ),
        ProtocolStep(
          label: 'Metronom 20/min',
          eventType: 'METRONOME_20_START',
          duration: Duration(seconds: 90),
          metronomeBpm: 20,
        ),
        ProtocolStep(
          label: 'Mowa',
          eventType: 'SPEECH_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Ruch / chód',
          eventType: 'WALK_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Kaszel',
          eventType: 'COUGH_START',
          duration: Duration(seconds: 30),
        ),
        ProtocolStep(
          label: 'Spoczynek końcowy',
          eventType: 'FINAL_REST_START',
          duration: Duration(seconds: 60),
        ),
      ];
  }
}

class CsvSessionLogger {
  String? sessionId;
  Directory? sessionDirectory;
  File? _metadataFile;
  File? _eventsFile;
  File? _qualityReportFile;
  final Map<DeviceType, File> _rawFiles = {};
  final Map<String, Future<void>> _writeQueues = {};
  Map<String, Object?> _metadata = {};

  bool get isActive => sessionId != null && sessionDirectory != null;

  List<XFile> get exportFiles {
    final files = <File>[
      if (_metadataFile != null) _metadataFile!,
      if (_eventsFile != null) _eventsFile!,
      ..._rawFiles.values,
      if (_qualityReportFile != null) _qualityReportFile!,
    ];
    return files.where((file) => file.existsSync()).map((file) {
      return XFile(file.path);
    }).toList();
  }

  Future<void> start({
    required String participantId,
    required ProtocolMode protocolMode,
    required List<DeviceConfig> selectedDevices,
    required String notes,
    required DateTime startedAt,
  }) async {
    final baseDir = await getApplicationDocumentsDirectory();
    final safeParticipant = _safeFilePart(
      participantId.trim().isEmpty ? 'UNKNOWN' : participantId.trim(),
    );
    sessionId = 'session_${_folderStamp(startedAt)}_$safeParticipant';
    sessionDirectory = Directory(_joinPath(baseDir.path, sessionId!));
    await sessionDirectory!.create(recursive: true);

    _metadataFile = _fileInSession('metadata.json');
    _eventsFile = _fileInSession('events.csv');
    _qualityReportFile = _fileInSession('quality_report.json');
    _rawFiles.clear();
    _writeQueues.clear();

    for (final config in deviceConfigs) {
      final file = _fileInSession(config.csvFileName);
      _rawFiles[config.deviceType] = file;
      await file.writeAsString('${_rawHeader(config)}\n');
    }
    await _eventsFile!.writeAsString(
      'session_id,timestamp_ms,datetime_iso,event_type,note\n',
    );

    _metadata = {
      'session_id': sessionId,
      'participant_id': participantId,
      'start_datetime': startedAt.toIso8601String(),
      'end_datetime': null,
      'selected_protocol': protocolMode.fileValue,
      'devices_used': selectedDevices.map((config) => config.toJson()).toList(),
      'notes': notes,
      'app_version': appVersion,
      'device_configs': deviceConfigs.map((config) => config.toJson()).toList(),
    };
    await _writeMetadata();
    await _qualityReportFile!.writeAsString('{}\n');
  }

  Future<void> logEvent({
    required int timestampMs,
    required DateTime dateTime,
    required String eventType,
    String note = '',
  }) async {
    if (!isActive || _eventsFile == null) return;
    final row = _csvRow([
      sessionId,
      timestampMs,
      dateTime.toIso8601String(),
      eventType,
      note,
    ]);
    await _appendLine(_eventsFile!, row);
  }

  Future<void> logSample({
    required DeviceConfig config,
    required int sampleIndex,
    required int timestampMs,
    required DateTime dateTime,
    required ParsedFrame frame,
  }) async {
    if (!isActive) return;
    final file = _rawFiles[config.deviceType];
    if (file == null) return;

    final base = [
      sessionId,
      sampleIndex,
      timestampMs,
      dateTime.toIso8601String(),
      config.displayName,
      frame.rawPayload,
    ];

    final row = switch (config.parserType) {
      ParserType.glassesCsv8 => _csvRow([
        ...base,
        frame.values['t0'] ?? '',
        frame.values['h0'] ?? '',
        frame.values['t1'] ?? '',
        frame.values['h1'] ?? '',
        frame.values['t2'] ?? '',
        frame.values['h2'] ?? '',
        frame.values['tAmb'] ?? '',
        frame.values['hAmb'] ?? '',
        frame.parseOk,
        frame.nanCount,
      ]),
      ParserType.rawHx711 => _csvRow([
        ...base,
        frame.values['raw_hx711'] ?? '',
        frame.parseOk,
      ]),
      ParserType.rawPressure => _csvRow([
        ...base,
        frame.values['raw_pressure'] ?? '',
        frame.parseOk,
      ]),
    };

    await _appendLine(file, row);
  }

  Future<void> finalize({
    required DateTime endedAt,
    required Iterable<DeviceRuntimeState> deviceStates,
  }) async {
    await _flushWrites();
    if (!isActive) return;

    _metadata['end_datetime'] = endedAt.toIso8601String();
    await _writeMetadata();

    final report = {
      'session_id': sessionId,
      'generated_at': DateTime.now().toIso8601String(),
      'devices': {
        for (final state in deviceStates)
          state.config.deviceType.name: state.quality.toJson(state.config),
      },
    };
    await _qualityReportFile?.writeAsString(
      const JsonEncoder.withIndent('  ').convert(report),
    );
  }

  Future<void> _writeMetadata() async {
    await _metadataFile?.writeAsString(
      const JsonEncoder.withIndent('  ').convert(_metadata),
    );
  }

  Future<void> _appendLine(File file, String row) {
    final previous = _writeQueues[file.path] ?? Future<void>.value();
    final next = previous.then<void>((_) async {
      await file.writeAsString('$row\n', mode: FileMode.append);
    });
    _writeQueues[file.path] = next.catchError((Object error, StackTrace stack) {
      debugPrint('Błąd zapisu CSV: $error');
    });
    return _writeQueues[file.path]!;
  }

  Future<void> _flushWrites() async {
    await Future.wait(_writeQueues.values);
  }

  File _fileInSession(String fileName) {
    return File(_joinPath(sessionDirectory!.path, fileName));
  }
}

class ResearchController extends ChangeNotifier {
  final Map<DeviceType, DeviceRuntimeState> devices = {
    for (final config in deviceConfigs)
      config.deviceType: DeviceRuntimeState(config),
  };
  final CsvSessionLogger logger = CsvSessionLogger();
  final Stopwatch _sessionStopwatch = Stopwatch();
  late final ProtocolController protocol;

  bool isSessionRunning = false;
  bool isStoppingSession = false;
  bool _scanInProgress = false;
  ProtocolMode selectedProtocol = ProtocolMode.technicalTest;
  String participantId = 'P001';
  String notes = '';
  String lastMessage = '';
  DateTime? sessionStartedAt;
  DateTime? sessionEndedAt;

  ResearchController() {
    protocol = ProtocolController(
      onEvent: _logProtocolEvent,
      onChanged: notifyListeners,
      onFinished: () => stopSession(shareAfterStop: false, autoStopped: true),
    );
  }

  int get selectedDeviceCount {
    return devices.values.where((state) => state.selected).length;
  }

  bool get canStartSession => !isSessionRunning && selectedDeviceCount > 0;

  void setParticipantId(String value) {
    participantId = value;
  }

  void setNotes(String value) {
    notes = value;
  }

  void setProtocol(ProtocolMode mode) {
    if (isSessionRunning) return;
    selectedProtocol = mode;
    notifyListeners();
  }

  void setDeviceSelected(DeviceType type, bool selected) {
    if (isSessionRunning) return;
    devices[type]?.selected = selected;
    notifyListeners();
  }

  Future<void> connectDevice(DeviceType type) async {
    final state = devices[type]!;
    if (state.isConnecting || state.isConnected) return;
    if (_scanInProgress) {
      state.status = 'Skanowanie innego urządzenia';
      notifyListeners();
      return;
    }

    state.isConnecting = true;
    state.status = 'Przygotowanie BLE...';
    _scanInProgress = true;
    notifyListeners();

    StreamSubscription<List<ScanResult>>? scanSub;
    BluetoothDevice? pendingDevice;
    try {
      await _ensureBleReady();
      await FlutterBluePlus.stopScan();

      final completer = Completer<BluetoothDevice?>();
      scanSub = FlutterBluePlus.onScanResults.listen((results) {
        for (final result in results) {
          final platformName = result.device.platformName;
          final advName = result.advertisementData.advName;
          if (platformName == state.config.bleName ||
              advName == state.config.bleName) {
            if (!completer.isCompleted) {
              completer.complete(result.device);
              unawaited(FlutterBluePlus.stopScan());
            }
            break;
          }
        }
      });

      state.status = 'Szukanie ${state.config.bleName}...';
      notifyListeners();
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 8));

      final foundDevice = await completer.future.timeout(
        const Duration(seconds: 9),
        onTimeout: () => null,
      );
      await FlutterBluePlus.stopScan();
      await scanSub.cancel();
      scanSub = null;

      if (foundDevice == null) {
        state.status = 'Nie znaleziono';
        return;
      }

      state.status = 'Łączenie...';
      notifyListeners();
      await foundDevice.connect(
        timeout: const Duration(seconds: 8),
        autoConnect: false,
      );
      pendingDevice = foundDevice;
      state.device = foundDevice;

      if (Platform.isAndroid) {
        try {
          await foundDevice.requestMtu(512);
          await Future<void>.delayed(const Duration(milliseconds: 200));
        } catch (error) {
          debugPrint('Nie udało się zwiększyć MTU: $error');
        }
      }

      final characteristic = await _findNotifyCharacteristic(
        foundDevice,
        state.config,
      );
      if (characteristic == null) {
        throw Exception('Brak wymaganej charakterystyki BLE');
      }

      state.notifySub = characteristic.lastValueStream.listen((value) {
        _onDataReceived(state.config.deviceType, value);
      });
      await characteristic.setNotifyValue(true);

      state.connectionSub = foundDevice.connectionState.listen((connection) {
        if (connection == BluetoothConnectionState.disconnected &&
            state.device != null) {
          state.notifySub?.cancel();
          state.notifySub = null;
          state.characteristic = null;
          state.device = null;
          state.status = 'Rozłączono';
          if (isSessionRunning) {
            state.quality.recordDisconnect();
          }
          notifyListeners();
        }
      });

      state.device = foundDevice;
      state.characteristic = characteristic;
      state.status = 'Połączono';
      state.series.clear();
      lastMessage = '${state.config.displayName}: połączono';
    } catch (error) {
      state.status = 'Błąd połączenia';
      lastMessage = '${state.config.displayName}: $error';
      debugPrint('Błąd BLE: $error');
      await (state.device ?? pendingDevice)?.disconnect();
      state.device = null;
      await state.notifySub?.cancel();
      state.notifySub = null;
      await state.connectionSub?.cancel();
      state.connectionSub = null;
    } finally {
      await scanSub?.cancel();
      state.isConnecting = false;
      _scanInProgress = false;
      notifyListeners();
    }
  }

  Future<void> disconnectDevice(DeviceType type) async {
    final state = devices[type]!;
    state.status = 'Rozłączanie...';
    notifyListeners();
    await state.notifySub?.cancel();
    await state.connectionSub?.cancel();
    await state.device?.disconnect();
    state.notifySub = null;
    state.connectionSub = null;
    state.characteristic = null;
    state.device = null;
    state.status = 'Rozłączono';
    notifyListeners();
  }

  Future<void> startSession() async {
    if (!canStartSession) return;
    final selectedDevices = devices.values
        .where((state) => state.selected)
        .map((state) => state.config)
        .toList();

    for (final state in devices.values) {
      state.resetForSession();
    }

    sessionStartedAt = DateTime.now();
    sessionEndedAt = null;
    await logger.start(
      participantId: participantId,
      protocolMode: selectedProtocol,
      selectedDevices: selectedDevices,
      notes: notes,
      startedAt: sessionStartedAt!,
    );

    _sessionStopwatch
      ..reset()
      ..start();
    isSessionRunning = true;
    lastMessage = 'Sesja rozpoczęta: ${logger.sessionId}';
    await _logEvent('SESSION_START', 'Start sesji');
    protocol.start(selectedProtocol);
    notifyListeners();
  }

  Future<void> stopSession({
    bool shareAfterStop = true,
    bool autoStopped = false,
  }) async {
    if (!isSessionRunning || isStoppingSession) return;
    isStoppingSession = true;
    protocol.stop();
    await _logEvent(
      'SESSION_STOP',
      autoStopped ? 'Automatyczny koniec protokołu' : 'Ręczne zatrzymanie',
    );
    _sessionStopwatch.stop();
    isSessionRunning = false;
    sessionEndedAt = DateTime.now();
    await logger.finalize(
      endedAt: sessionEndedAt!,
      deviceStates: devices.values,
    );
    lastMessage = 'Sesja zapisana: ${logger.sessionId}';
    isStoppingSession = false;
    notifyListeners();
    if (shareAfterStop) {
      await shareLastSession();
    }
  }

  Future<void> shareLastSession() async {
    final files = logger.exportFiles;
    if (files.isEmpty) {
      lastMessage = 'Brak plików do eksportu';
      notifyListeners();
      return;
    }
    await Share.shareXFiles(
      files,
      text: 'Dane sesji badawczej: ${logger.sessionId ?? ''}',
    );
  }

  void addManualMarker(String markerName) {
    if (!isSessionRunning) return;
    unawaited(_logEvent(markerName, 'Marker ręczny'));
    lastMessage = 'Dodano marker: $markerName';
    notifyListeners();
  }

  Future<void> _logProtocolEvent(String eventType, String note) {
    return _logEvent(eventType, note);
  }

  Future<void> _logEvent(String eventType, String note) {
    if (!logger.isActive) return Future<void>.value();
    return logger.logEvent(
      timestampMs: _sessionStopwatch.elapsedMilliseconds,
      dateTime: DateTime.now(),
      eventType: eventType,
      note: note,
    );
  }

  Future<void> _ensureBleReady() async {
    if (!Platform.isAndroid) return;
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.location,
    ].request();
    try {
      await FlutterBluePlus.turnOn();
    } catch (error) {
      debugPrint('Nie udało się wymusić włączenia Bluetooth: $error');
    }
  }

  Future<BluetoothCharacteristic?> _findNotifyCharacteristic(
    BluetoothDevice device,
    DeviceConfig config,
  ) async {
    final services = await device.discoverServices();
    for (final service in services) {
      if (service.uuid.str.toLowerCase() != config.serviceUuid.toLowerCase()) {
        continue;
      }
      for (final characteristic in service.characteristics) {
        if (characteristic.uuid.str.toLowerCase() ==
            config.characteristicUuid.toLowerCase()) {
          return characteristic;
        }
      }
    }
    return null;
  }

  void _onDataReceived(DeviceType type, List<int> value) {
    if (value.isEmpty) return;
    final state = devices[type]!;
    final text = utf8.decode(value, allowMalformed: true).trim();
    debugPrint('${state.config.bleName} RAW: $text');

    final timestampMs = isSessionRunning
        ? _sessionStopwatch.elapsedMilliseconds
        : DateTime.now().millisecondsSinceEpoch;
    final frame = parseFrame(state.config, text);
    state.quality.recordSample(
      timestampMs: timestampMs,
      parseOk: frame.parseOk,
      frameNanCount: frame.nanCount,
    );
    state.addPlotValues(frame.plotValues);

    if (isSessionRunning && logger.isActive) {
      final sampleIndex = state.nextSampleIndex();
      unawaited(
        logger.logSample(
          config: state.config,
          sampleIndex: sampleIndex,
          timestampMs: _sessionStopwatch.elapsedMilliseconds,
          dateTime: DateTime.now(),
          frame: frame,
        ),
      );
    }
    notifyListeners();
  }

  @override
  void dispose() {
    protocol.dispose();
    for (final state in devices.values) {
      unawaited(state.notifySub?.cancel());
      unawaited(state.connectionSub?.cancel());
      unawaited(state.device?.disconnect());
    }
    super.dispose();
  }
}

ParsedFrame parseFrame(DeviceConfig config, String text) {
  switch (config.parserType) {
    case ParserType.glassesCsv8:
      return _parseGlassesFrame(text);
    case ParserType.rawHx711:
      return _parseSingleRawFrame(
        text: text,
        valueKey: 'raw_hx711',
        plotKey: 'raw_hx711',
      );
    case ParserType.rawPressure:
      return _parseSingleRawFrame(
        text: text,
        valueKey: 'raw_pressure',
        plotKey: 'raw_pressure',
      );
  }
}

ParsedFrame _parseGlassesFrame(String text) {
  final parts = text.split(',').map((part) => part.trim()).toList();
  const keys = ['t0', 'h0', 't1', 'h1', 't2', 'h2', 'tAmb', 'hAmb'];
  if (parts.length != keys.length) {
    return ParsedFrame(
      rawPayload: text,
      parseOk: false,
      values: const {},
      plotValues: const {},
      nanCount: 0,
    );
  }

  final values = <String, String>{};
  final plotValues = <String, double>{};
  var parseOk = true;
  var nanCount = 0;

  for (var i = 0; i < keys.length; i++) {
    final raw = parts[i];
    values[keys[i]] = raw;
    final normalized = raw.toLowerCase();
    if (normalized == 'nan') {
      nanCount++;
      continue;
    }
    final parsed = double.tryParse(raw);
    if (parsed == null || !parsed.isFinite) {
      parseOk = false;
      continue;
    }
    plotValues[keys[i]] = parsed;
  }

  return ParsedFrame(
    rawPayload: text,
    parseOk: parseOk,
    values: values,
    plotValues: plotValues,
    nanCount: nanCount,
  );
}

ParsedFrame _parseSingleRawFrame({
  required String text,
  required String valueKey,
  required String plotKey,
}) {
  final parsed = double.tryParse(text.trim());
  final parseOk = parsed != null && parsed.isFinite;
  return ParsedFrame(
    rawPayload: text,
    parseOk: parseOk,
    values: parseOk ? {valueKey: text.trim()} : const {},
    plotValues: parseOk ? {plotKey: parsed} : const {},
    nanCount: 0,
  );
}

class ResearchApp extends StatelessWidget {
  const ResearchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0F4C81)),
        scaffoldBackgroundColor: const Color(0xFFF4F7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Color(0xFF0F4C81),
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      home: const ResearchHomePage(),
    );
  }
}

class ResearchHomePage extends StatefulWidget {
  const ResearchHomePage({super.key});

  @override
  State<ResearchHomePage> createState() => _ResearchHomePageState();
}

class _ResearchHomePageState extends State<ResearchHomePage> {
  final ResearchController _ctrl = ResearchController();
  late final TextEditingController _participantController;
  late final TextEditingController _notesController;
  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _participantController = TextEditingController(text: _ctrl.participantId)
      ..addListener(() => _ctrl.setParticipantId(_participantController.text));
    _notesController = TextEditingController(text: _ctrl.notes)
      ..addListener(() => _ctrl.setNotes(_notesController.text));
  }

  @override
  void dispose() {
    _participantController.dispose();
    _notesController.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('NOSE - Rejestrator Badawczy')),
      body: ListenableBuilder(
        listenable: _ctrl,
        builder: (context, _) {
          return IndexedStack(
            index: _tabIndex,
            children: [
              _buildConfigTab(),
              _buildBleTab(),
              _buildSessionTab(),
              _buildPreviewTab(),
              _buildExportTab(),
            ],
          );
        },
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (index) => setState(() => _tabIndex = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.tune_outlined),
            selectedIcon: Icon(Icons.tune),
            label: 'Sesja',
          ),
          NavigationDestination(
            icon: Icon(Icons.bluetooth_searching),
            selectedIcon: Icon(Icons.bluetooth_connected),
            label: 'BLE',
          ),
          NavigationDestination(
            icon: Icon(Icons.timer_outlined),
            selectedIcon: Icon(Icons.timer),
            label: 'Protokół',
          ),
          NavigationDestination(
            icon: Icon(Icons.show_chart),
            selectedIcon: Icon(Icons.show_chart),
            label: 'Dane',
          ),
          NavigationDestination(
            icon: Icon(Icons.ios_share_outlined),
            selectedIcon: Icon(Icons.ios_share),
            label: 'Eksport',
          ),
        ],
      ),
    );
  }

  Widget _buildConfigTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Konfiguracja sesji'),
        TextField(
          controller: _participantController,
          enabled: !_ctrl.isSessionRunning,
          decoration: const InputDecoration(
            labelText: 'Participant ID',
            prefixIcon: Icon(Icons.badge_outlined),
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<ProtocolMode>(
          initialValue: _ctrl.selectedProtocol,
          decoration: const InputDecoration(
            labelText: 'Tryb badania',
            prefixIcon: Icon(Icons.assignment_outlined),
            border: OutlineInputBorder(),
          ),
          items: ProtocolMode.values.map((mode) {
            return DropdownMenuItem(value: mode, child: Text(mode.label));
          }).toList(),
          onChanged: _ctrl.isSessionRunning
              ? null
              : (mode) {
                  if (mode != null) _ctrl.setProtocol(mode);
                },
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _notesController,
          enabled: !_ctrl.isSessionRunning,
          minLines: 3,
          maxLines: 5,
          decoration: const InputDecoration(
            labelText: 'Notatki',
            alignLabelWithHint: true,
            prefixIcon: Icon(Icons.notes_outlined),
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 20),
        _sectionTitle('Urządzenia użyte w sesji'),
        ..._ctrl.devices.values.map(_buildDeviceSelectionTile),
        const SizedBox(height: 16),
        _InfoPanel(
          icon: Icons.info_outline,
          text:
              'Aplikacja zapisuje wyłącznie dane surowe z BLE, timestampy, markery i metadane. Analiza sygnału zostaje do Pythona.',
        ),
      ],
    );
  }

  Widget _buildDeviceSelectionTile(DeviceRuntimeState state) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: CheckboxListTile(
        value: state.selected,
        onChanged: _ctrl.isSessionRunning
            ? null
            : (value) => _ctrl.setDeviceSelected(
                state.config.deviceType,
                value ?? false,
              ),
        title: Text(state.config.displayName),
        subtitle: Text(state.config.bleName),
        secondary: const Icon(Icons.sensors),
      ),
    );
  }

  Widget _buildBleTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Połączenia BLE'),
        ..._ctrl.devices.values.map((state) {
          return _DeviceConnectionCard(
            state: state,
            onConnect: () => _ctrl.connectDevice(state.config.deviceType),
            onDisconnect: () => _ctrl.disconnectDevice(state.config.deviceType),
          );
        }),
        if (_ctrl.lastMessage.isNotEmpty) ...[
          const SizedBox(height: 8),
          _InfoPanel(icon: Icons.terminal_outlined, text: _ctrl.lastMessage),
        ],
      ],
    );
  }

  Widget _buildSessionTab() {
    final protocol = _ctrl.protocol;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Protokół badawczy'),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                protocol.currentStepLabel,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF0F4C81),
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                _formatDuration(Duration(seconds: protocol.remainingSeconds)),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Następny etap: ${protocol.nextStepLabel}',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.black54),
              ),
              if (protocol.currentMetronomeBpm > 0) ...[
                const SizedBox(height: 24),
                _MetronomeView(protocol: protocol),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 56,
          child: ElevatedButton.icon(
            onPressed: _ctrl.isStoppingSession
                ? null
                : () {
                    if (_ctrl.isSessionRunning) {
                      _ctrl.stopSession();
                    } else {
                      _ctrl.startSession();
                    }
                  },
            icon: Icon(
              _ctrl.isSessionRunning
                  ? Icons.stop_circle_outlined
                  : Icons.fiber_manual_record,
            ),
            label: Text(
              _ctrl.isSessionRunning ? 'ZAKOŃCZ I EKSPORTUJ' : 'START SESJI',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _ctrl.isSessionRunning
                  ? Colors.red.shade700
                  : Colors.green.shade700,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _sectionTitle('Markery ręczne'),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final marker in const [
              'SYNC',
              'MOWA',
              'RUCH',
              'KASZEL',
              'BEZDECH',
              'ARTEFAKT',
              'UWAGA',
            ])
              ActionChip(
                avatar: const Icon(Icons.flag_outlined, size: 18),
                label: Text(marker),
                onPressed: _ctrl.isSessionRunning
                    ? () => _ctrl.addManualMarker(marker)
                    : null,
              ),
          ],
        ),
      ],
    );
  }

  Widget _buildPreviewTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Podgląd surowych danych'),
        ..._ctrl.devices.values.map((state) {
          return _ChartPanel(state: state);
        }),
      ],
    );
  }

  Widget _buildExportTab() {
    final logger = _ctrl.logger;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionTitle('Eksport'),
        _SummaryRow(label: 'Session ID', value: logger.sessionId ?? '-'),
        _SummaryRow(
          label: 'Folder',
          value: logger.sessionDirectory?.path ?? '-',
        ),
        _SummaryRow(
          label: 'Start',
          value: _ctrl.sessionStartedAt?.toIso8601String() ?? '-',
        ),
        _SummaryRow(
          label: 'Koniec',
          value: _ctrl.sessionEndedAt?.toIso8601String() ?? '-',
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 52,
          child: ElevatedButton.icon(
            onPressed: logger.exportFiles.isEmpty
                ? null
                : _ctrl.shareLastSession,
            icon: const Icon(Icons.ios_share),
            label: const Text('UDOSTĘPNIJ PLIKI SESJI'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0F4C81),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _sectionTitle('Raport jakości'),
        ..._ctrl.devices.values.map((state) {
          return _QualityReportTile(state: state);
        }),
      ],
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF0F4C81),
          fontSize: 18,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _DeviceConnectionCard extends StatelessWidget {
  final DeviceRuntimeState state;
  final VoidCallback onConnect;
  final VoidCallback onDisconnect;

  const _DeviceConnectionCard({
    required this.state,
    required this.onConnect,
    required this.onDisconnect,
  });

  @override
  Widget build(BuildContext context) {
    final isConnected = state.isConnected;
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  isConnected ? Icons.bluetooth_connected : Icons.bluetooth,
                  color: isConnected ? Colors.green.shade700 : Colors.grey,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        state.config.displayName,
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                      Text(
                        state.config.bleName,
                        style: const TextStyle(color: Colors.black54),
                      ),
                    ],
                  ),
                ),
                FilledButton.icon(
                  onPressed: state.isConnecting
                      ? null
                      : isConnected
                      ? onDisconnect
                      : onConnect,
                  icon: Icon(
                    isConnected
                        ? Icons.bluetooth_disabled
                        : Icons.bluetooth_searching,
                  ),
                  label: Text(
                    isConnected
                        ? 'Rozłącz'
                        : state.isConnecting
                        ? 'Szukam'
                        : 'Połącz',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _MetricChip(label: 'Status', value: state.status),
                _MetricChip(
                  label: 'Próbki',
                  value: '${state.quality.sampleCount}',
                ),
                _MetricChip(
                  label: 'Hz',
                  value: state.quality.averageHz.toStringAsFixed(2),
                ),
                _MetricChip(
                  label: 'Błędy',
                  value: '${state.quality.badFrameCount}',
                ),
                _MetricChip(label: 'nan', value: '${state.quality.nanCount}'),
                _MetricChip(
                  label: 'Ostatnia',
                  value: state.quality.lastSampleAgeLabel(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ChartPanel extends StatelessWidget {
  final DeviceRuntimeState state;

  const _ChartPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    final series = state.series.entries.where((entry) {
      if (state.config.parserType == ParserType.glassesCsv8) {
        return const {'t0', 't1', 't2', 'tAmb'}.contains(entry.key);
      }
      return true;
    }).toList();

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              state.config.displayName,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            Text(
              'Podgląd raw, bez filtrów i bez analizy DSP',
              style: TextStyle(color: Colors.grey.shade700),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 220,
              child: series.isEmpty
                  ? const Center(child: Text('Brak danych'))
                  : LineChart(
                      LineChartData(
                        gridData: FlGridData(show: true),
                        titlesData: FlTitlesData(show: false),
                        borderData: FlBorderData(show: false),
                        lineBarsData: [
                          for (var i = 0; i < series.length; i++)
                            LineChartBarData(
                              spots: series[i].value,
                              isCurved: false,
                              color: _seriesColor(i),
                              barWidth: 2,
                              dotData: FlDotData(show: false),
                            ),
                        ],
                      ),
                    ),
            ),
            if (series.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 10,
                runSpacing: 6,
                children: [
                  for (var i = 0; i < series.length; i++)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: _seriesColor(i),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(series[i].key),
                      ],
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _MetronomeView extends StatelessWidget {
  final ProtocolController protocol;

  const _MetronomeView({required this.protocol});

  @override
  Widget build(BuildContext context) {
    final inhale = protocol.isMetronomeInhale;
    final size = inhale ? 170.0 : 105.0;
    return Center(
      child: AnimatedContainer(
        duration: Duration(
          milliseconds: (60000 / protocol.currentMetronomeBpm / 2).round(),
        ),
        width: size,
        height: size,
        curve: Curves.easeInOutSine,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: inhale ? Colors.blue.shade100 : Colors.teal.shade100,
          shape: BoxShape.circle,
          border: Border.all(
            color: inhale ? Colors.blue.shade700 : Colors.teal.shade700,
            width: 4,
          ),
        ),
        child: Text(
          inhale ? 'WDECH' : 'WYDECH',
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }
}

class _QualityReportTile extends StatelessWidget {
  final DeviceRuntimeState state;

  const _QualityReportTile({required this.state});

  @override
  Widget build(BuildContext context) {
    final status = state.quality.statusFor(state.config.nominalSamplingHz);
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    state.config.displayName,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                Chip(label: Text(status)),
              ],
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _MetricChip(
                  label: 'Próbki',
                  value: '${state.quality.sampleCount}',
                ),
                _MetricChip(
                  label: 'Śr. Hz',
                  value: state.quality.averageHz.toStringAsFixed(2),
                ),
                _MetricChip(
                  label: 'Min dt',
                  value: state.quality.minIntervalMs?.toString() ?? '-',
                ),
                _MetricChip(
                  label: 'Max dt',
                  value: state.quality.maxIntervalMs?.toString() ?? '-',
                ),
                _MetricChip(
                  label: 'Błędy',
                  value: '${state.quality.badFrameCount}',
                ),
                _MetricChip(label: 'nan', value: '${state.quality.nanCount}'),
                _MetricChip(
                  label: 'Rozłączenia',
                  value: '${state.quality.disconnectCount}',
                ),
                _MetricChip(
                  label: 'Poprawne',
                  value: '${state.quality.validPercent.toStringAsFixed(1)}%',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricChip extends StatelessWidget {
  final String label;
  final String value;

  const _MetricChip({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF1F8),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _InfoPanel extends StatelessWidget {
  final IconData icon;
  final String text;

  const _InfoPanel({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF1F8),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF0F4C81)),
          const SizedBox(width: 10),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;

  const _SummaryRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 92,
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.black54,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Expanded(child: SelectableText(value)),
        ],
      ),
    );
  }
}

Color _seriesColor(int index) {
  const colors = [
    Color(0xFF0F4C81),
    Color(0xFF2E7D32),
    Color(0xFFF9A825),
    Color(0xFFC62828),
    Color(0xFF6A1B9A),
    Color(0xFF00838F),
    Color(0xFF5D4037),
    Color(0xFF455A64),
  ];
  return colors[index % colors.length];
}

String _rawHeader(DeviceConfig config) {
  switch (config.parserType) {
    case ParserType.glassesCsv8:
      return [
        'session_id',
        'sample_index',
        'timestamp_ms',
        'datetime_iso',
        'device_name',
        'raw_payload',
        't0',
        'h0',
        't1',
        'h1',
        't2',
        'h2',
        'tAmb',
        'hAmb',
        'parse_ok',
        'nan_count',
      ].join(',');
    case ParserType.rawHx711:
      return [
        'session_id',
        'sample_index',
        'timestamp_ms',
        'datetime_iso',
        'device_name',
        'raw_payload',
        'raw_hx711',
        'parse_ok',
      ].join(',');
    case ParserType.rawPressure:
      return [
        'session_id',
        'sample_index',
        'timestamp_ms',
        'datetime_iso',
        'device_name',
        'raw_payload',
        'raw_pressure',
        'parse_ok',
      ].join(',');
  }
}

String _csvRow(Iterable<Object?> values) {
  return values.map(_csvCell).join(',');
}

String _csvCell(Object? value) {
  final text = value?.toString() ?? '';
  if (text.contains(',') || text.contains('"') || text.contains('\n')) {
    return '"${text.replaceAll('"', '""')}"';
  }
  return text;
}

String _formatDuration(Duration duration) {
  final totalSeconds = math.max(0, duration.inSeconds);
  final minutes = totalSeconds ~/ 60;
  final seconds = totalSeconds % 60;
  return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
}

String _folderStamp(DateTime value) {
  String two(int number) => number.toString().padLeft(2, '0');
  return '${value.year}${two(value.month)}${two(value.day)}_'
      '${two(value.hour)}${two(value.minute)}${two(value.second)}';
}

String _safeFilePart(String value) {
  return value.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
}

String _joinPath(String left, String right) {
  return '$left${Platform.pathSeparator}$right';
}
