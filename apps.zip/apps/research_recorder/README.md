# NOSE - rejestrator badawczy

Aplikacja łączy się niezależnie z trzema urządzeniami BLE, zapisuje nieprzetworzone
ramki pomiarowe i markery protokołu oraz eksportuje pliki sesji. Każdy aktywny tor
ma osobny stan połączenia, licznik próbek i plik danych.

W pracy wykorzystano protokoły stałego metronomu, chodu, zmiennego metronomu oraz
chodu i biegu. Aplikacja rejestrująca nie wykonuje interpretacji klinicznej ani
analizy sygnału w czasie rzeczywistym.

## Budowanie

```text
flutter pub get
flutter analyze
flutter build apk --release
```

Gotowy wariant instalacyjny znajduje się w głównym katalogu repozytorium pod
ścieżką `releases/NOSE-research-recorder-android.apk`.
