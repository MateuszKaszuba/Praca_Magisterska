package com.example.nose_rejestrator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
