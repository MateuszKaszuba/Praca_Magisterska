import 'package:flutter_test/flutter_test.dart';
import 'package:nose_rejestrator/main.dart';

void main() {
  testWidgets('research app starts', (tester) async {
    await tester.pumpWidget(const ResearchApp());

    expect(find.text('NOSE - Rejestrator Badawczy'), findsOneWidget);
    expect(find.text('Konfiguracja sesji'), findsOneWidget);
  });
}
